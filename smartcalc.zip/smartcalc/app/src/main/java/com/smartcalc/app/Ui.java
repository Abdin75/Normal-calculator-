package com.smartcalc.app;

import android.graphics.drawable.GradientDrawable;

/** Small helpers so every screen shares the same look. */
final class Ui {

    static final int BG_TOP = 0xFF0E1128;
    static final int BG_BOTTOM = 0xFF1C1140;
    static final int CARD = 0xFF1A2038;
    static final int CARD_LINE = 0xFF2C3556;
    static final int ACCENT = 0xFFFFC107;
    static final int TEXT = 0xFFECEFF9;
    static final int MUTED = 0xFF8E99C0;

    private Ui() {
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static GradientDrawable gradient(int top, int bottom, float radiusPx) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {top, bottom});
        g.setCornerRadius(radiusPx);
        return g;
    }

    static GradientDrawable card(float dp) {
        GradientDrawable g = round(CARD, 16 * dp);
        g.setStroke((int) Math.max(1, dp), CARD_LINE);
        return g;
    }

    static GradientDrawable page() {
        return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {BG_TOP, BG_BOTTOM});
    }
}
