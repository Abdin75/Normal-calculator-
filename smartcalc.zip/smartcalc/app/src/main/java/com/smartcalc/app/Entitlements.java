package com.smartcalc.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;

import java.util.Locale;

/**
 * Which paid features are unlocked. Payment itself happens on a web page (your payment link);
 * the app only checks unlock codes locally, by hash. There is no server that can verify a payment.
 */
final class Entitlements {

    static final int GIFTS = 0;
    static final int PUZZLES = 1;
    static final int IMAGES = 2;
    static final int PRODUCTS = 3;

    private final Resources res;
    private final SharedPreferences sp;
    private final String salt;

    Entitlements(Context c, Store s) {
        res = c.getResources();
        sp = s.prefs();
        salt = s.salt();
    }

    /** Same cleaning on the phone and in the generator: upper case letters and digits only. */
    static String clean(String typed) {
        return typed.toUpperCase(Locale.ROOT).replaceAll("[^A-Z0-9]", "");
    }

    // ------------------------------------------------------------------ owner

    boolean owner() {
        return ("OWNER|" + salt).equals(Secure.dec(sp.getString("own", "")));
    }

    void setOwner(boolean on) {
        if (on) {
            sp.edit().putString("own", Secure.enc("OWNER|" + salt)).apply();
        } else {
            sp.edit().remove("own").apply();
        }
    }

    boolean checkOwnerKey(String typed) {
        String c = clean(typed);
        if (c.length() < 8) {
            return false;
        }
        if (Norm.sha256Hex(c).equalsIgnoreCase(res.getString(R.string.owner_hash))) {
            setOwner(true);
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ unlocked products

    private int mask() {
        String raw = sp.getString("ent", "");
        if (raw.length() == 0) {
            return 0;
        }
        if (!Norm.sha256Hex(raw + "|ent|" + salt).equals(sp.getString("entc", ""))) {
            return 0;
        }
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private void saveMask(int m) {
        String raw = Integer.toString(m);
        sp.edit().putString("ent", raw).putString("entc", Norm.sha256Hex(raw + "|ent|" + salt)).apply();
    }

    boolean has(int product) {
        return owner() || (mask() & (1 << product)) != 0;
    }

    void resetPurchases() {
        sp.edit().remove("ent").remove("entc").apply();
    }

    /** Tries an unlock code. Returns the product it unlocked, or -1. */
    int tryCode(String typed) {
        String c = clean(typed);
        if (c.length() < 6) {
            return -1;
        }
        String h = Norm.sha256Hex(c);
        int[] lists = {R.array.codes_gifts, R.array.codes_puzzles, R.array.codes_images};
        for (int p = 0; p < PRODUCTS; p++) {
            for (String x : res.getStringArray(lists[p])) {
                if (x.equalsIgnoreCase(h)) {
                    saveMask(mask() | (1 << p));
                    return p;
                }
            }
        }
        return -1;
    }

    // ------------------------------------------------------------------ product texts and payment links

    String name(int p) {
        return res.getStringArray(R.array.product_names)[p];
    }

    String desc(int p) {
        return res.getStringArray(R.array.product_desc)[p];
    }

    String price(int p) {
        return res.getStringArray(R.array.product_prices)[p];
    }

    private int linkRes(int p) {
        return p == GIFTS ? R.string.pay_link_gifts : (p == PUZZLES ? R.string.pay_link_puzzles : R.string.pay_link_images);
    }

    /** A link saved on this phone (encrypted) wins over the one built into the app. */
    String link(int p) {
        String own = Secure.dec(sp.getString("link" + p, ""));
        String url = own.length() > 0 ? own : res.getString(linkRes(p));
        url = url.trim();
        return url.startsWith("https://") ? url : "";
    }

    void setLink(int p, String url) {
        String u = url.trim();
        if (u.length() == 0) {
            sp.edit().remove("link" + p).apply();
        } else {
            sp.edit().putString("link" + p, Secure.enc(u)).apply();
        }
    }

    String savedLink(int p) {
        return Secure.dec(sp.getString("link" + p, ""));
    }
}
