package com.smartcalc.app;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.BitSet;

/** Progress as a set of solved puzzle ids in private storage, with a checksum against edits. */
final class Store {

    static final String PREFS = "smartcalc";

    private final SharedPreferences sp;
    private final String salt;
    private BitSet bits = new BitSet();
    boolean tampered;

    Store(Context c) {
        sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long t = 0;
        try {
            t = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).firstInstallTime;
        } catch (Exception ignored) {
            // keep 0
        }
        salt = "sc|" + t;
        refresh();
    }

    String salt() {
        return salt;
    }

    private static BitSet parse(String raw) {
        BitSet b = new BitSet();
        if (raw.length() == 0) {
            return b;
        }
        String[] parts = raw.split(",");
        long[] l = new long[parts.length];
        try {
            for (int i = 0; i < parts.length; i++) {
                l[i] = Long.parseLong(parts[i]);
            }
        } catch (NumberFormatException e) {
            return new BitSet();
        }
        return BitSet.valueOf(l);
    }

    private String serialize() {
        long[] l = bits.toLongArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.length; i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(l[i]);
        }
        return sb.toString();
    }

    void refresh() {
        String raw = sp.getString("b", "");
        if (raw.length() > 0 && !Norm.sha256Hex(raw + "|" + salt).equals(sp.getString("c", ""))) {
            tampered = true;
            bits = new BitSet();
            save();
            return;
        }
        bits = parse(raw);
    }

    private void save() {
        String raw = serialize();
        sp.edit().putString("b", raw).putString("c", Norm.sha256Hex(raw + "|" + salt)).apply();
    }

    boolean has(int id) {
        return bits.get(id);
    }

    /** Marks a puzzle solved. Returns true only the first time. */
    boolean set(int id) {
        refresh();
        if (bits.get(id)) {
            return false;
        }
        bits.set(id);
        save();
        return true;
    }

    int count() {
        return bits.cardinality();
    }

    void clearAll() {
        bits = new BitSet();
        save();
    }

    int bump(String key) {
        int v = sp.getInt(key, 0) + 1;
        sp.edit().putInt(key, v).apply();
        return v;
    }

    int get(String key) {
        return sp.getInt(key, 0);
    }

    void put(String key, int value) {
        sp.edit().putInt(key, value).apply();
    }

    SharedPreferences prefs() {
        return sp;
    }
}
