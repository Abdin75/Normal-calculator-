package com.smartcalc.app;

import android.content.Context;
import android.content.SharedPreferences;

/** Progress is a bit mask in private storage, plus a checksum so edits are noticed. */
final class Store {

    static final String PREFS = "smartcalc";

    private final SharedPreferences sp;
    private final String salt;
    private long mask;
    boolean tampered;

    Store(Context c) {
        sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long t = 0;
        try {
            t = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).firstInstallTime;
        } catch (Exception ignored) {
            // keep 0
        }
        salt = "sc|" + t;
        refresh();
    }

    void refresh() {
        long v = 0;
        try {
            v = Long.parseLong(sp.getString("m", "0"));
        } catch (NumberFormatException e) {
            v = 0;
        }
        if (v != 0 && !Norm.sha256Hex(v + "|" + salt).equals(sp.getString("c", ""))) {
            tampered = true;
            v = 0;
            mask = 0;
            save();
        }
        mask = v;
    }

    private void save() {
        sp.edit().putString("m", Long.toString(mask))
                .putString("c", Norm.sha256Hex(mask + "|" + salt)).apply();
    }

    boolean has(int id) {
        return (mask & (1L << id)) != 0;
    }

    /** Marks a puzzle solved. Returns true only the first time. */
    boolean set(int id) {
        refresh();
        if (has(id)) {
            return false;
        }
        mask |= (1L << id);
        save();
        return true;
    }

    int count() {
        return Long.bitCount(mask);
    }

    int bump(String key) {
        int v = sp.getInt(key, 0) + 1;
        sp.edit().putInt(key, v).apply();
        return v;
    }

    SharedPreferences prefs() {
        return sp;
    }
}
