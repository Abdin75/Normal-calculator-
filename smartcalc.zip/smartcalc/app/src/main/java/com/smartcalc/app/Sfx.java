package com.smartcalc.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Sounds made from maths: short tones generated on the fly. No audio files at all. */
final class Sfx {

    static final int SOLVE = 0;
    static final int WRONG = 1;
    static final int SECRET = 2;
    static final int FANFARE = 3;
    static final int SAD = 4;
    static final int POP = 5;
    static final int COIN = 6;

    private static final int RATE = 22050;

    private final SharedPreferences sp;

    Sfx(Context c) {
        sp = c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE);
    }

    boolean enabled() {
        return sp.getBoolean("sound", true);
    }

    void setEnabled(boolean on) {
        sp.edit().putBoolean("sound", on).apply();
    }

    private static int[][] melody(int type) {
        switch (type) {
            case SOLVE:
                return new int[][] {{523, 90}, {659, 90}, {784, 90}, {1047, 180}};
            case WRONG:
                return new int[][] {{180, 150}, {140, 230}};
            case SECRET:
                return new int[][] {{392, 70}, {523, 70}, {659, 70}, {784, 70}, {988, 70}, {1175, 220}};
            case FANFARE:
                return new int[][] {{523, 140}, {523, 140}, {523, 140}, {659, 300}, {523, 140}, {659, 140}, {784, 520}};
            case SAD:
                return new int[][] {{392, 260}, {370, 260}, {349, 260}, {330, 620}};
            case COIN:
                return new int[][] {{988, 80}, {1319, 260}};
            default:
                return new int[][] {{880, 60}, {1320, 90}};
        }
    }

    private static short[] synth(int[][] seq) {
        int total = 0;
        for (int[] n : seq) {
            total += RATE * n[1] / 1000;
        }
        short[] pcm = new short[total];
        int pos = 0;
        for (int[] n : seq) {
            int len = RATE * n[1] / 1000;
            for (int i = 0; i < len; i++) {
                float env = Math.min(1f, Math.min(i / 250f, (len - i) / 500f));
                double v = Math.sin(2 * Math.PI * n[0] * i / RATE) * 0.30
                        + Math.sin(4 * Math.PI * n[0] * i / RATE) * 0.08;
                pcm[pos + i] = (short) (v * env * 32767);
            }
            pos += len;
        }
        return pcm;
    }

    void play(final int type) {
        if (!enabled()) {
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                AudioTrack t = null;
                try {
                    short[] pcm = synth(melody(type));
                    t = new AudioTrack.Builder()
                            .setAudioAttributes(new AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_GAME)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build())
                            .setAudioFormat(new AudioFormat.Builder()
                                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                                    .setSampleRate(RATE)
                                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                                    .build())
                            .setBufferSizeInBytes(pcm.length * 2)
                            .setTransferMode(AudioTrack.MODE_STATIC)
                            .build();
                    t.write(pcm, 0, pcm.length);
                    t.play();
                    Thread.sleep(pcm.length * 1000L / RATE + 150);
                } catch (Exception ignored) {
                    // no sound is better than a crash
                } finally {
                    if (t != null) {
                        t.release();
                    }
                }
            }
        }).start();
    }
}
