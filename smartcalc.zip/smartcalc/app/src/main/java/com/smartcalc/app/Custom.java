package com.smartcalc.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/** Number puzzles the player makes (a paid feature): a code, a message and an optional picture. */
final class Custom {

    static final int MAX = 20;

    static final class Item {
        String hash;
        String digits;
        String message;
        String image;
    }

    private final SharedPreferences sp;

    Custom(Context c) {
        sp = c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE);
    }

    ArrayList<Item> list() {
        ArrayList<Item> out = new ArrayList<Item>();
        try {
            JSONArray a = new JSONArray(sp.getString("custom", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.hash = o.getString("h");
                it.digits = Secure.dec(o.optString("d", ""));
                it.message = o.getString("m");
                it.image = o.optString("i", "");
                out.add(it);
            }
        } catch (Exception e) {
            // corrupted: start empty
        }
        return out;
    }

    private void save(ArrayList<Item> items) {
        JSONArray a = new JSONArray();
        try {
            for (Item it : items) {
                JSONObject o = new JSONObject();
                o.put("h", it.hash);
                o.put("d", Secure.enc(it.digits == null ? "" : it.digits));
                o.put("m", it.message);
                o.put("i", it.image == null ? "" : it.image);
                a.put(o);
            }
        } catch (Exception e) {
            return;
        }
        sp.edit().putString("custom", a.toString()).apply();
    }

    /** Returns an error code: 0 ok, 1 bad input, 2 already used, 3 list full. */
    int add(String digits, String message, String image) {
        if (!digits.matches("[0-9]{2,12}") || message.trim().length() == 0) {
            return 1;
        }
        ArrayList<Item> items = list();
        if (items.size() >= MAX) {
            return 3;
        }
        String h = Norm.sha256Hex(digits);
        for (Item it : items) {
            if (it.hash.equals(h)) {
                return 2;
            }
        }
        Item n = new Item();
        n.hash = h;
        n.digits = digits;
        n.message = message.trim();
        n.image = image == null ? "" : image;
        items.add(n);
        save(items);
        return 0;
    }

    void remove(int index) {
        ArrayList<Item> items = list();
        if (index >= 0 && index < items.size()) {
            items.remove(index);
            save(items);
        }
    }

    Item match(String digits) {
        String h = Norm.sha256Hex(digits);
        for (Item it : list()) {
            if (it.hash.equals(h)) {
                return it;
            }
        }
        return null;
    }
}
