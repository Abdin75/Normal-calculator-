package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

/** The lab: three small games, each drawn and handled by one custom View. */
public class PlayActivity extends Activity {

    private interface Listener {
        void onSolved();

        void onWrong(int count);
    }

    private Store store;
    private Puzzles puzzles;
    private TextView help;

    // ------------------------------------------------------------------ star map

    private static final class StarsView extends View {
        private final Listener listener;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float dp;
        private int next;
        private int wrong;
        private boolean done;

        StarsView(Context c, Listener l) {
            super(c);
            listener = l;
            dp = c.getResources().getDisplayMetrics().density;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float u = Math.min(w, h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF0B1026);
            c.drawRect(0, 0, w, h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(0xFF90CAF9);
            p.setStrokeWidth(2 * dp);
            for (int i = 0; i < next - 1; i++) {
                c.drawLine(ArtView.SX[i] * w, ArtView.SY[i] * h, ArtView.SX[i + 1] * w, ArtView.SY[i + 1] * h, p);
            }
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < ArtView.SX.length; i++) {
                float r = ArtView.SR[i] * u * 1.6f;
                p.setColor(0x33FFFFFF);
                c.drawCircle(ArtView.SX[i] * w, ArtView.SY[i] * h, r * 2f, p);
                p.setColor(i < next ? 0xFFFFB300 : 0xFFFFFFFF);
                c.drawCircle(ArtView.SX[i] * w, ArtView.SY[i] * h, r, p);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN || done) {
                return true;
            }
            float w = getWidth();
            float h = getHeight();
            float u = Math.min(w, h);
            int hit = -1;
            float best = Float.MAX_VALUE;
            for (int i = 0; i < ArtView.SX.length; i++) {
                float dx = e.getX() - ArtView.SX[i] * w;
                float dy = e.getY() - ArtView.SY[i] * h;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                float limit = ArtView.SR[i] * u * 1.6f * 2.2f + 12 * dp;
                if (d < limit && d < best) {
                    best = d;
                    hit = i;
                }
            }
            if (hit < 0) {
                return true;
            }
            if (hit == next) {
                next++;
                invalidate();
                if (next == ArtView.SX.length) {
                    done = true;
                    listener.onSolved();
                }
            } else {
                next = 0;
                wrong++;
                invalidate();
                listener.onWrong(wrong);
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ hidden key

    private static final class KeyHuntView extends View {
        private static final float KX = 0.82f;
        private static final float KY = 0.63f;
        private final Listener listener;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final float dp;
        private final float[] dx = new float[45];
        private final float[] dy = new float[45];
        private final float[] ds = new float[45];
        private int wrong;
        private boolean done;

        KeyHuntView(Context c, Listener l) {
            super(c);
            listener = l;
            dp = c.getResources().getDisplayMetrics().density;
            Random r = new Random(7);
            for (int i = 0; i < dx.length; i++) {
                dx[i] = 0.05f + 0.90f * r.nextFloat();
                dy[i] = 0.52f + 0.44f * r.nextFloat();
                ds[i] = 0.7f + 0.8f * r.nextFloat();
            }
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float u = Math.min(w, h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF81D4FA);
            c.drawRect(0, 0, w, 0.55f * h, p);
            p.setColor(0xFF607D8B);
            path.reset();
            path.moveTo(0, 0.55f * h);
            path.lineTo(0.18f * w, 0.28f * h);
            path.lineTo(0.38f * w, 0.55f * h);
            path.lineTo(0.62f * w, 0.55f * h);
            path.lineTo(0.80f * w, 0.30f * h);
            path.lineTo(w, 0.55f * h);
            path.close();
            c.drawPath(path, p);
            p.setColor(0xFF2E7D32);
            c.drawRect(0, 0.55f * h, w, h, p);
            for (int i = 0; i < dx.length; i++) {
                p.setColor(0xFF6D4C41);
                c.drawCircle(dx[i] * w, dy[i] * h, 0.014f * u * ds[i], p);
                p.setColor(0xFF4E342E);
                c.drawCircle(dx[i] * w, dy[i] * h - 0.010f * u * ds[i], 0.008f * u * ds[i], p);
            }
            p.setColor(0xFFB8860B);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.006f * u);
            c.drawCircle(KX * w, KY * h, 0.012f * u, p);
            c.drawLine(KX * w + 0.012f * u, KY * h, KX * w + 0.04f * u, KY * h, p);
            c.drawLine(KX * w + 0.034f * u, KY * h, KX * w + 0.034f * u, KY * h + 0.014f * u, p);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getActionMasked() != MotionEvent.ACTION_DOWN || done) {
                return true;
            }
            float u = Math.min(getWidth(), getHeight());
            float dxp = e.getX() - (KX * getWidth() + 0.02f * u);
            float dyp = e.getY() - KY * getHeight();
            if (Math.sqrt(dxp * dxp + dyp * dyp) < 0.05f * u + 10 * dp) {
                done = true;
                listener.onSolved();
            } else {
                wrong++;
                listener.onWrong(wrong);
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ scratch card

    private static final class ScratchView extends View {
        private static final int COLS = 20;
        private static final int ROWS = 14;
        private final Listener listener;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final boolean[] erased = new boolean[COLS * ROWS];
        private final String label;
        private final String digit;
        private int erasedCount;
        private boolean done;

        ScratchView(Context c, Listener l, String label, String digit) {
            super(c);
            listener = l;
            this.label = label;
            this.digit = digit;
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            float u = Math.min(w, h);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF263238);
            c.drawRect(0, 0, w, h, p);
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(0xFFB0BEC5);
            p.setTextSize(0.07f * u);
            c.drawText(label, w / 2f, 0.38f * h, p);
            p.setColor(0xFFFFD54F);
            p.setTextSize(0.40f * u);
            c.drawText(digit, w / 2f, 0.72f * h, p);
            float cw = w / COLS;
            float ch = h / ROWS;
            for (int r = 0; r < ROWS; r++) {
                for (int k = 0; k < COLS; k++) {
                    if (!erased[r * COLS + k]) {
                        p.setColor(((r + k) % 2 == 0) ? 0xFFD4AF37 : 0xFFC9A227);
                        c.drawRect(k * cw, r * ch, (k + 1) * cw + 1, (r + 1) * ch + 1, p);
                    }
                }
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int a = e.getActionMasked();
            if (a != MotionEvent.ACTION_DOWN && a != MotionEvent.ACTION_MOVE) {
                return true;
            }
            int col = (int) (e.getX() / (getWidth() / (float) COLS));
            int row = (int) (e.getY() / (getHeight() / (float) ROWS));
            for (int dr = -1; dr <= 1; dr++) {
                for (int dc = -1; dc <= 1; dc++) {
                    int r = row + dr;
                    int k = col + dc;
                    if (r >= 0 && r < ROWS && k >= 0 && k < COLS && !erased[r * COLS + k]) {
                        erased[r * COLS + k] = true;
                        erasedCount++;
                    }
                }
            }
            invalidate();
            if (!done && erasedCount >= COLS * ROWS * 35 / 100) {
                done = true;
                listener.onSolved();
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ screen

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        float dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        if (!store.has(Puzzles.KNOCK)) {
            finish();
            return;
        }
        final int mode = getIntent().getIntExtra("mode", 0);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF101418);
        int pad = (int) (12 * dp);
        root.setPadding(pad, pad, pad, pad);

        help = new TextView(this);
        help.setTextSize(15);
        help.setTextColor(0xFFECEFF1);
        help.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        help.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        help.setPadding(0, 0, 0, pad);
        root.addView(help, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));

        Listener listener;
        View game;
        if (mode == 1) {
            help.setText(R.string.play_key_help);
            listener = new Listener() {
                @Override
                public void onSolved() {
                    solved(Puzzles.KEYHUNT);
                }

                @Override
                public void onWrong(int count) {
                    if (count == 12) {
                        help.setText(R.string.play_key_wrong2);
                    } else if (count % 5 == 0) {
                        help.setText(R.string.play_key_wrong1);
                    }
                }
            };
            game = new KeyHuntView(this, listener);
        } else if (mode == 2) {
            help.setText(R.string.play_scratch_help);
            listener = new Listener() {
                @Override
                public void onSolved() {
                    solved(Puzzles.SCRATCH);
                }

                @Override
                public void onWrong(int count) {
                    // nothing can be wrong when scratching
                }
            };
            String d = puzzles.digit(Puzzles.SCRATCH);
            game = new ScratchView(this, listener, getString(R.string.play_scratch_label), d.length() > 0 ? d : "?");
        } else {
            help.setText(R.string.play_stars_help);
            listener = new Listener() {
                @Override
                public void onSolved() {
                    solved(Puzzles.STARS);
                }

                @Override
                public void onWrong(int count) {
                    help.setText(R.string.play_stars_wrong);
                }
            };
            game = new StarsView(this, listener);
        }
        FrameLayout holder = new FrameLayout(this);
        holder.addView(game, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(holder, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button back = new Button(this);
        back.setText(R.string.play_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        root.addView(back, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(root);
    }

    private void solved(int id) {
        String m = puzzles.solve(id);
        new AlertDialog.Builder(this)
                .setMessage(m != null ? m : getString(R.string.already_solved))
                .setPositiveButton(R.string.ok, null).show();
    }
}
