package com.smartcalc.app;

import java.math.BigDecimal;
import java.util.Locale;

/** Tiny expression evaluator: + - * / % ( ) and decimals. Pure Java (no Android). */
final class Calc {

    private final String s;
    private int pos;

    private Calc(String s) {
        this.s = s;
    }

    static double eval(String expression) {
        Calc c = new Calc(expression);
        double v = c.expr();
        if (c.pos != c.s.length()) {
            throw new IllegalArgumentException("unexpected input");
        }
        return v;
    }

    private char peek() {
        return pos < s.length() ? s.charAt(pos) : '\0';
    }

    private double expr() {
        double v = term();
        while (true) {
            char c = peek();
            if (c == '+') {
                pos++;
                v += term();
            } else if (c == '-') {
                pos++;
                v -= term();
            } else {
                return v;
            }
        }
    }

    private double term() {
        double v = unary();
        while (true) {
            char c = peek();
            if (c == '*') {
                pos++;
                v *= unary();
            } else if (c == '/') {
                pos++;
                double d = unary();
                if (d == 0) {
                    throw new ArithmeticException("division by zero");
                }
                v /= d;
            } else {
                return v;
            }
        }
    }

    private double unary() {
        if (peek() == '-') {
            pos++;
            return -unary();
        }
        if (peek() == '+') {
            pos++;
            return unary();
        }
        return postfix();
    }

    private double postfix() {
        double v = primary();
        while (peek() == '%') {
            pos++;
            v /= 100.0;
        }
        return v;
    }

    private double primary() {
        if (peek() == '(') {
            pos++;
            double v = expr();
            if (peek() != ')') {
                throw new IllegalArgumentException("missing )");
            }
            pos++;
            return v;
        }
        int start = pos;
        while ((peek() >= '0' && peek() <= '9') || peek() == '.') {
            pos++;
        }
        if (start == pos) {
            throw new IllegalArgumentException("number expected");
        }
        return Double.parseDouble(s.substring(start, pos));
    }

    /** Plain decimal text. 0.1+0.2 keeps its famous extra digits on purpose. */
    static String format(double v) {
        if (Double.isNaN(v) || Double.isInfinite(v)) {
            return "Error";
        }
        if (v == 0) {
            return "0";
        }
        String t = BigDecimal.valueOf(v).stripTrailingZeros().toPlainString();
        if (t.length() > 24) {
            t = String.format(Locale.ROOT, "%.8e", v);
        }
        return t;
    }
}
