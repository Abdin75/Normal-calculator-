package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Meme cards you earn by solving puzzles, plus six golden ones that come from the shop. */
public class GiftsActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;

    private Store store;
    private Puzzles puzzles;
    private Entitlements ent;
    private float dp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        ent = new Entitlements(this, store);
        if (!store.has(Puzzles.KNOCK)) {
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (store.has(Puzzles.KNOCK)) {
            store.refresh();
            build();
        }
    }

    private boolean unlocked(int need) {
        return need >= 0 ? puzzles.solvedCount() >= need : ent.has(Entitlements.GIFTS);
    }

    private void build() {
        final String[] glyphs = getResources().getStringArray(R.array.gift_glyphs);
        final String[] titles = getResources().getStringArray(R.array.gift_titles);
        final String[] caps = getResources().getStringArray(R.array.gift_captions);
        final int[] need = getResources().getIntArray(R.array.gift_need);
        int n = Math.min(Math.min(glyphs.length, titles.length), Math.min(caps.length, need.length));

        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.page());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (14 * dp);
        box.setPadding(pad, pad, pad, pad * 2);
        sv.addView(box);

        int open = 0;
        for (int i = 0; i < n; i++) {
            if (unlocked(need[i])) {
                open++;
            }
        }
        TextView head = new TextView(this);
        head.setText(getString(R.string.gifts_title) + "   " + open + " / " + n);
        head.setTextSize(24);
        head.setTextColor(Ui.ACCENT);
        head.setPadding(0, 0, 0, pad);
        box.addView(head);

        LinearLayout row = null;
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row, new LinearLayout.LayoutParams(MATCH, (int) (170 * dp)));
            }
            final int idx = i;
            final boolean isOpen = unlocked(need[i]);
            String lock = need[i] >= 0
                    ? getString(R.string.gifts_locked_free, String.valueOf(need[i]), String.valueOf(puzzles.solvedCount()))
                    : getString(R.string.gifts_locked_paid);
            GiftView gv = new GiftView(this, glyphs[i], titles[i], caps[i], i, !isOpen, lock);
            gv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showCard(idx, glyphs[idx], titles[idx], caps[idx], isOpen, need[idx]);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
            int m = (int) (5 * dp);
            lp.setMargins(m, m, m, m);
            row.addView(gv, lp);
        }
        if (n % 2 == 1 && row != null) {
            row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        }
        setContentView(sv);
    }

    private void showCard(int idx, String glyph, String title, String caption, boolean open, int need) {
        if (open) {
            GiftView big = new GiftView(this, glyph, title, caption, idx, false, "");
            big.setLayoutParams(new ViewGroup.LayoutParams(MATCH, (int) (320 * dp)));
            new AlertDialog.Builder(this).setView(big).setPositiveButton(R.string.close, null).show();
            return;
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        if (need >= 0) {
            b.setMessage(getString(R.string.gifts_locked_free, String.valueOf(need),
                    String.valueOf(puzzles.solvedCount())));
        } else {
            b.setMessage(R.string.gifts_locked_paid);
            b.setNeutralButton(R.string.gifts_open_shop, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int which) {
                    startActivity(new Intent(GiftsActivity.this, ShopActivity.class));
                }
            });
        }
        b.setPositiveButton(R.string.ok, null).show();
    }
}
