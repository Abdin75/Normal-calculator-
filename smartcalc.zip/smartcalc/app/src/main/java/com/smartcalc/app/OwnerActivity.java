package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Owner panel: payment links (encrypted on this phone), a hash tool, and test switches. */
public class OwnerActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Store store;
    private Entitlements ent;
    private float dp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        ent = new Entitlements(this, store);
        if (!ent.owner()) {
            finish();
            return;
        }
        build();
    }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.card(dp));
        int p = (int) (14 * dp);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, 0, 0, (int) (12 * dp));
        parent.addView(c, lp);
        return c;
    }

    private TextView pill(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTextColor(Ui.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.gradient(0xFF3A2E6E, 0xFF2D2358, 14 * dp));
        int p = (int) (12 * dp);
        t.setPadding(p, p, p, p);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, (int) (6 * dp), 0, 0);
        t.setLayoutParams(lp);
        return t;
    }

    private EditText field(String hint, String value) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setText(value);
        et.setSingleLine(true);
        et.setTextColor(0xFFFFFFFF);
        et.setHintTextColor(0xFF607D8B);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        et.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        return et;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.page());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (14 * dp);
        box.setPadding(pad, pad, pad, pad * 2);
        sv.addView(box);

        TextView title = tv("\uD83D\uDD11 " + getString(R.string.owner_title), 26, Ui.ACCENT);
        title.setPadding(0, 0, 0, pad);
        box.addView(title);

        LinearLayout links = card(box);
        links.addView(tv(getString(R.string.owner_links), 16, Ui.TEXT));
        final EditText[] fields = new EditText[Entitlements.PRODUCTS];
        for (int p = 0; p < Entitlements.PRODUCTS; p++) {
            links.addView(tv(ent.name(p) + "  " + ent.price(p), 13, Ui.MUTED));
            fields[p] = field("https://...", ent.savedLink(p));
            links.addView(fields[p]);
        }
        links.addView(pill(getString(R.string.owner_save), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int p = 0; p < fields.length; p++) {
                    String u = fields[p].getText().toString().trim();
                    if (u.length() > 0 && !u.startsWith("https://")) {
                        toast(getString(R.string.owner_bad_link));
                        return;
                    }
                }
                for (int p = 0; p < fields.length; p++) {
                    ent.setLink(p, fields[p].getText().toString());
                }
                toast(getString(R.string.owner_saved));
            }
        }));
        links.addView(tv(getString(R.string.owner_note), 12, Ui.MUTED));

        LinearLayout tool = card(box);
        tool.addView(tv(getString(R.string.owner_hash_title), 15, Ui.TEXT));
        final EditText in = field("", "");
        in.setInputType(InputType.TYPE_CLASS_TEXT);
        tool.addView(in);
        final TextView out = tv("", 12, 0xFF80CBC4);
        out.setTextIsSelectable(true);
        tool.addView(pill(getString(R.string.owner_hash_btn), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                out.setText(Norm.sha256Hex(Entitlements.clean(in.getText().toString())));
            }
        }));
        tool.addView(out);

        LinearLayout act = card(box);
        act.addView(pill(getString(R.string.owner_lock), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ent.resetPurchases();
                toast(getString(R.string.owner_done));
            }
        }));
        act.addView(pill(getString(R.string.owner_reset), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(OwnerActivity.this).setMessage(R.string.owner_reset)
                        .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                store.clearAll();
                                toast(getString(R.string.owner_done));
                            }
                        }).setNegativeButton(R.string.close, null).show();
            }
        }));
        act.addView(pill(getString(R.string.owner_logout), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ent.setOwner(false);
                finish();
            }
        }));
        setContentView(sv);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
