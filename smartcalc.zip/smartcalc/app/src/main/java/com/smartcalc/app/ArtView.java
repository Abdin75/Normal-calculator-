package com.smartcalc.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/**
 * Pictures drawn with code. No picture file exists inside the app or on the phone,
 * so there is nothing a file manager could replace.
 */
final class ArtView extends View {

    /** Star map shared with the constellation game: index 0 is the faintest, 6 the brightest. */
    static final float[] SX = {0.22f, 0.70f, 0.45f, 0.80f, 0.30f, 0.62f, 0.50f};
    static final float[] SY = {0.30f, 0.20f, 0.46f, 0.58f, 0.72f, 0.80f, 0.14f};
    static final float[] SR = {0.012f, 0.017f, 0.022f, 0.027f, 0.032f, 0.038f, 0.045f};

    private final int art;
    private final boolean locked;
    private final float dp;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private Bitmap custom;
    private boolean video;
    private boolean hasCustom;

    ArtView(Context c, int art, boolean locked) {
        super(c);
        this.art = art;
        this.locked = locked;
        dp = c.getResources().getDisplayMetrics().density;
    }

    /** Shows the user's own picture or video poster instead of the built-in drawing. */
    void setCustom(Bitmap b, boolean isVideo) {
        custom = b;
        video = isVideo;
        hasCustom = true;
        invalidate();
    }

    private void fill(int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
    }

    private void stroke(int color, float width) {
        p.setStyle(Paint.Style.STROKE);
        p.setColor(color);
        p.setStrokeWidth(width);
    }

    private void bg(Canvas c, float w, float h, int color) {
        fill(color);
        c.drawRoundRect(0, 0, w, h, 10 * dp, 10 * dp, p);
    }

    private float rnd(int i, int salt) {
        int v = (i * 73856093) ^ (salt * 19349663);
        v = v * 0x45d9f3b;
        v ^= v >>> 16;
        return (v & 0xFFFF) / 65535f;
    }

    private void scatter(Canvas c, float w, float h, int n, int salt) {
        float u = Math.min(w, h);
        fill(0xCCFFFFFF);
        for (int i = 0; i < n; i++) {
            c.drawCircle(rnd(i, salt) * w, rnd(i, salt + 101) * h, (0.004f + 0.008f * rnd(i, salt + 7)) * u, p);
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        if (hasCustom) {
            drawCustom(c, w, h);
            return;
        }
        if (locked) {
            drawLocked(c, w, h);
            return;
        }
        switch (art) {
            case 0:
                door(c, w, h);
                break;
            case 1:
                planet(c, w, h);
                break;
            case 2:
                blackHole(c, w, h);
                break;
            case 3:
                ghost(c, w, h);
                break;
            case 4:
                moon(c, w, h);
                break;
            case 5:
                mouse(c, w, h);
                break;
            case 6:
                keyboard(c, w, h);
                break;
            case 7:
                window(c, w, h);
                break;
            case 8:
                crown(c, w, h);
                break;
            case 9:
                constellation(c, w, h);
                break;
            case 10:
                keyShape(c, w, h);
                break;
            case 11:
                chest(c, w, h);
                break;
            case 12:
                sunrise(c, w, h);
                break;
            case 13:
                pi(c, w, h);
                break;
            default:
                drawLocked(c, w, h);
                break;
        }
    }

    private void drawLocked(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF1A1F24);
        fill(0xFF455A64);
        p.setTextAlign(Paint.Align.CENTER);
        p.setTextSize(u * 0.5f);
        c.drawText("?", w / 2f, h / 2f + u * 0.18f, p);
    }

    private void drawCustom(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF000000);
        if (custom != null) {
            float bw = custom.getWidth();
            float bh = custom.getHeight();
            float s = Math.min(w / bw, h / bh);
            float dw = bw * s;
            float dh = bh * s;
            rf.set(w / 2f - dw / 2f, h / 2f - dh / 2f, w / 2f + dw / 2f, h / 2f + dh / 2f);
            c.drawBitmap(custom, null, rf, p);
        }
        if (video) {
            fill(0x99000000);
            c.drawCircle(w / 2f, h / 2f, 0.16f * u, p);
            fill(0xFFFFFFFF);
            path.reset();
            path.moveTo(w / 2f - 0.05f * u, h / 2f - 0.08f * u);
            path.lineTo(w / 2f - 0.05f * u, h / 2f + 0.08f * u);
            path.lineTo(w / 2f + 0.09f * u, h / 2f);
            path.close();
            c.drawPath(path, p);
        }
    }

    // ------------------------------------------------------------------ the pictures

    private void door(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF2B2118);
        float x0 = 0.30f * w;
        float x1 = 0.70f * w;
        float y0 = 0.10f * h;
        float y1 = 0.92f * h;
        fill(0xFFFFE082);
        c.drawRect(x0 + 0.02f * w, y1 - 0.01f * h, x1 - 0.02f * w, y1 + 0.03f * h, p);
        fill(0xFF8D5524);
        c.drawRect(x0, y0, x1, y1, p);
        fill(0xFF6D4118);
        c.drawRect(x0 + 0.04f * w, y0 + 0.06f * h, x1 - 0.04f * w, y0 + 0.38f * h, p);
        c.drawRect(x0 + 0.04f * w, y0 + 0.46f * h, x1 - 0.04f * w, y1 - 0.06f * h, p);
        fill(0xFFFFD54F);
        c.drawCircle(x1 - 0.07f * w, (y0 + y1) / 2f, 0.03f * u, p);
        fill(0xFF000000);
        c.drawCircle(x1 - 0.07f * w, (y0 + y1) / 2f + 0.07f * h, 0.012f * u, p);
    }

    private void planet(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF0B1026);
        scatter(c, w, h, 30, 1);
        fill(0xFFFFA726);
        c.drawCircle(w / 2f, h / 2f, 0.22f * u, p);
        fill(0xFFFB8C00);
        c.drawCircle(w / 2f - 0.07f * u, h / 2f - 0.07f * u, 0.05f * u, p);
        stroke(0xFFFFE0B2, 0.025f * u);
        rf.set(w / 2f - 0.38f * u, h / 2f - 0.08f * u, w / 2f + 0.38f * u, h / 2f + 0.08f * u);
        c.drawOval(rf, p);
    }

    private void blackHole(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF05050A);
        scatter(c, w, h, 30, 3);
        int[] cols = {0xFF7B1FA2, 0xFFE65100, 0xFFFFB300, 0xFFFFF59D};
        for (int k = 0; k < 4; k++) {
            stroke(cols[k], 0.03f * u);
            c.drawCircle(w / 2f, h / 2f, (0.34f - 0.045f * k) * u, p);
        }
        fill(0xFF000000);
        c.drawCircle(w / 2f, h / 2f, 0.17f * u, p);
    }

    private void ghost(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF1A1A2E);
        float s = 0.62f * u;
        c.save();
        c.translate(w / 2f - s / 2f, h / 2f - s / 2f);
        rf.set(0.08f * s, 0.04f * s, 0.92f * s, 0.84f * s);
        path.reset();
        path.arcTo(rf, 180f, 180f);
        path.lineTo(0.92f * s, 0.96f * s);
        path.lineTo(0.77f * s, 0.84f * s);
        path.lineTo(0.62f * s, 0.96f * s);
        path.lineTo(0.50f * s, 0.84f * s);
        path.lineTo(0.38f * s, 0.96f * s);
        path.lineTo(0.23f * s, 0.84f * s);
        path.lineTo(0.08f * s, 0.96f * s);
        path.close();
        fill(0xFFF5F5F5);
        c.drawPath(path, p);
        fill(0xFF000000);
        c.drawCircle(0.36f * s, 0.38f * s, 0.07f * s, p);
        c.drawCircle(0.64f * s, 0.38f * s, 0.07f * s, p);
        c.drawCircle(0.50f * s, 0.58f * s, 0.05f * s, p);
        c.restore();
    }

    private void moon(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF0D1B3E);
        scatter(c, w, h, 40, 5);
        fill(0xFFFFF59D);
        c.drawCircle(w / 2f, h / 2f, 0.26f * u, p);
        fill(0xFF0D1B3E);
        c.drawCircle(w / 2f + 0.11f * u, h / 2f - 0.06f * u, 0.23f * u, p);
    }

    private void mouse(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        float cx = w / 2f;
        float cy = h / 2f;
        bg(c, w, h, 0xFF263238);
        rf.set(cx - 0.17f * u, cy - 0.28f * u, cx + 0.17f * u, cy + 0.30f * u);
        fill(0xFFECEFF1);
        c.drawRoundRect(rf, 0.17f * u, 0.17f * u, p);
        stroke(0xFF90A4AE, 0.012f * u);
        c.drawLine(cx, rf.top, cx, cy - 0.05f * u, p);
        c.drawLine(rf.left + 0.01f * u, cy - 0.05f * u, rf.right - 0.01f * u, cy - 0.05f * u, p);
        fill(0xFF455A64);
        c.drawRoundRect(cx - 0.02f * u, cy - 0.20f * u, cx + 0.02f * u, cy - 0.10f * u,
                0.02f * u, 0.02f * u, p);
        stroke(0xFF90A4AE, 0.012f * u);
        path.reset();
        path.moveTo(cx, rf.top);
        path.quadTo(cx, 0.06f * h, cx - 0.22f * w, 0.08f * h);
        c.drawPath(path, p);
    }

    private void keyboard(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF263238);
        fill(0xFFCFD8DC);
        c.drawRoundRect(0.08f * w, 0.28f * h, 0.92f * w, 0.76f * h, 0.04f * u, 0.04f * u, p);
        fill(0xFF455A64);
        for (int r = 0; r < 3; r++) {
            for (int k = 0; k < 8; k++) {
                float x = 0.13f * w + k * 0.095f * w;
                float y = 0.33f * h + r * 0.11f * h;
                c.drawRoundRect(x, y, x + 0.07f * w, y + 0.08f * h, 0.01f * u, 0.01f * u, p);
            }
        }
        c.drawRoundRect(0.28f * w, 0.64f * h, 0.72f * w, 0.72f * h, 0.01f * u, 0.01f * u, p);
    }

    private void window(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF37474F);
        fill(0xFFECEFF1);
        c.drawRoundRect(0.12f * w, 0.18f * h, 0.88f * w, 0.84f * h, 0.04f * u, 0.04f * u, p);
        fill(0xFF1E88E5);
        c.drawRect(0.12f * w, 0.18f * h, 0.88f * w, 0.30f * h, p);
        fill(0xFFFFFFFF);
        for (int i = 0; i < 3; i++) {
            c.drawCircle((0.70f + 0.06f * i) * w, 0.24f * h, 0.015f * u, p);
        }
        fill(0xFFB0BEC5);
        c.drawRect(0.18f * w, 0.38f * h, 0.62f * w, 0.42f * h, p);
        c.drawRect(0.18f * w, 0.47f * h, 0.52f * w, 0.51f * h, p);
        fill(0xFF90CAF9);
        c.drawRoundRect(0.42f * w, 0.58f * h, 0.82f * w, 0.74f * h, 0.03f * u, 0.03f * u, p);
    }

    private void crown(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF311B92);
        path.reset();
        path.moveTo(0.22f * w, 0.72f * h);
        path.lineTo(0.18f * w, 0.32f * h);
        path.lineTo(0.36f * w, 0.50f * h);
        path.lineTo(0.50f * w, 0.24f * h);
        path.lineTo(0.64f * w, 0.50f * h);
        path.lineTo(0.82f * w, 0.32f * h);
        path.lineTo(0.78f * w, 0.72f * h);
        path.close();
        fill(0xFFFFC107);
        c.drawPath(path, p);
        fill(0xFFFF8F00);
        c.drawRect(0.22f * w, 0.72f * h, 0.78f * w, 0.80f * h, p);
        fill(0xFFE91E63);
        c.drawCircle(0.50f * w, 0.76f * h, 0.03f * u, p);
        fill(0xFFFFFFFF);
        c.drawCircle(0.18f * w, 0.30f * h, 0.025f * u, p);
        c.drawCircle(0.50f * w, 0.22f * h, 0.025f * u, p);
        c.drawCircle(0.82f * w, 0.30f * h, 0.025f * u, p);
    }

    private void constellation(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF0B1026);
        scatter(c, w, h, 30, 9);
        stroke(0xFF90CAF9, 0.008f * u);
        for (int i = 0; i < SX.length - 1; i++) {
            c.drawLine(SX[i] * w, SY[i] * h, SX[i + 1] * w, SY[i + 1] * h, p);
        }
        fill(0xFFFFFFFF);
        for (int i = 0; i < SX.length; i++) {
            c.drawCircle(SX[i] * w, SY[i] * h, SR[i] * u * 1.4f, p);
        }
    }

    private void keyShape(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF1B5E20);
        stroke(0xFFFFD54F, 0.05f * u);
        c.drawCircle(0.32f * w, 0.5f * h, 0.11f * u, p);
        c.drawLine(0.32f * w + 0.11f * u, 0.5f * h, 0.80f * w, 0.5f * h, p);
        c.drawLine(0.70f * w, 0.5f * h, 0.70f * w, 0.5f * h + 0.12f * u, p);
        c.drawLine(0.80f * w, 0.5f * h, 0.80f * w, 0.5f * h + 0.09f * u, p);
    }

    private void chest(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF4E342E);
        fill(0xFF8D6E63);
        c.drawRect(0.2f * w, 0.46f * h, 0.8f * w, 0.78f * h, p);
        rf.set(0.2f * w, 0.28f * h, 0.8f * w, 0.64f * h);
        c.drawArc(rf, 180f, 180f, true, p);
        fill(0xFFFFC107);
        c.drawRect(0.47f * w, 0.30f * h, 0.53f * w, 0.78f * h, p);
        fill(0xFFFFD54F);
        c.drawCircle(0.5f * w, 0.55f * h, 0.035f * u, p);
        fill(0xFF000000);
        c.drawCircle(0.5f * w, 0.55f * h, 0.012f * u, p);
        stroke(0xFFFFFFFF, 0.01f * u);
        c.drawLine(0.80f * w, 0.18f * h, 0.80f * w, 0.30f * h, p);
        c.drawLine(0.74f * w, 0.24f * h, 0.86f * w, 0.24f * h, p);
    }

    private void sunrise(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFFFFAB91);
        fill(0xFFFFCC80);
        c.drawRect(0, 0.40f * h, w, 0.75f * h, p);
        fill(0xFFFFF176);
        c.drawCircle(w / 2f, 0.60f * h, 0.22f * u, p);
        fill(0xFF4E342E);
        path.reset();
        path.moveTo(0, h);
        path.lineTo(0, 0.70f * h);
        path.quadTo(0.25f * w, 0.55f * h, 0.5f * w, 0.72f * h);
        path.quadTo(0.75f * w, 0.60f * h, w, 0.70f * h);
        path.lineTo(w, h);
        path.close();
        c.drawPath(path, p);
        fill(0xFF3E2723);
        path.reset();
        path.moveTo(0, h);
        path.lineTo(0, 0.86f * h);
        path.quadTo(0.4f * w, 0.76f * h, w, 0.88f * h);
        path.lineTo(w, h);
        path.close();
        c.drawPath(path, p);
    }

    private void pi(Canvas c, float w, float h) {
        float u = Math.min(w, h);
        bg(c, w, h, 0xFF1A237E);
        stroke(0xFFFFFFFF, 0.06f * u);
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(0.25f * w, 0.32f * h, 0.75f * w, 0.32f * h, p);
        c.drawLine(0.38f * w, 0.32f * h, 0.36f * w, 0.72f * h, p);
        path.reset();
        path.moveTo(0.62f * w, 0.32f * h);
        path.lineTo(0.62f * w, 0.62f * h);
        path.quadTo(0.62f * w, 0.74f * h, 0.72f * w, 0.72f * h);
        c.drawPath(path, p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }
}
