package com.smartcalc.app;

import java.util.HashSet;
import java.util.Locale;

/** Local password strength check for the signup puzzle. Nothing is stored or sent anywhere. */
final class PasswordCheck {

    static final int VERY_WEAK = 0;
    static final int WEAK = 1;
    static final int OK = 2;
    static final int GOOD = 3;
    static final int STRONG = 4;

    private static final String[] COMMON = {
            "123456", "password", "12345678", "qwerty", "123456789", "12345", "1234", "111111",
            "1234567", "dragon", "123123", "baseball", "abc123", "football", "monkey", "letmein",
            "696969", "shadow", "master", "666666", "qwertyuiop", "123321", "mustang", "1234567890",
            "654321", "superman", "1qaz2wsx", "7777777", "121212", "000000", "qazwsx", "123qwe",
            "trustno1", "zxcvbnm", "asdfgh", "asdfghjkl", "batman", "sunshine", "iloveyou", "admin",
            "welcome", "login", "passw0rd", "p@ssw0rd", "password1", "qwerty123", "abc12345",
            "princess", "azerty", "hello", "freedom", "whatever", "charlie", "aa123456", "root",
            "guest", "1q2w3e4r", "1q2w3e", "zaq12wsx", "987654321", "11111111", "00000000",
            "12341234", "qwer1234", "a1b2c3", "pass", "pass123", "secret", "love", "test", "test123",
            "user", "changeme", "default", "computer", "internet", "samsung", "tecno", "android",
            "google", "facebook", "habibi", "mohamed", "ahmed", "admin123", "111222", "112233"};

    private static final String[] BAD_WORDS = {"password", "qwerty", "admin", "letmein", "iloveyou",
            "welcome", "123456", "abcdef", "azerty"};

    private static final String[] KEYBOARD_ROWS = {"qwertyuiop", "asdfghjkl", "zxcvbnm", "1234567890",
            "azertyuiop", "qsdfghjklm"};

    private static final HashSet<String> COMMON_SET = new HashSet<String>();

    static {
        for (String s : COMMON) {
            COMMON_SET.add(s);
        }
    }

    private PasswordCheck() {
    }

    private static boolean allSame(String p) {
        for (int i = 1; i < p.length(); i++) {
            if (p.charAt(i) != p.charAt(0)) {
                return false;
            }
        }
        return true;
    }

    /** True if the whole text is a run like 12345678 or abcdefgh (up or down). */
    private static boolean isRun(String p) {
        if (p.length() < 4) {
            return false;
        }
        int step = p.charAt(1) - p.charAt(0);
        if (step != 1 && step != -1) {
            return false;
        }
        for (int i = 1; i < p.length(); i++) {
            if (p.charAt(i) - p.charAt(i - 1) != step) {
                return false;
            }
        }
        return true;
    }

    private static boolean keyboardRun(String p) {
        if (p.length() < 5) {
            return false;
        }
        for (String row : KEYBOARD_ROWS) {
            String rev = new StringBuilder(row).reverse().toString();
            if (row.contains(p) || rev.contains(p)) {
                return true;
            }
        }
        return false;
    }

    private static boolean mentions(String lowerPassword, String thing) {
        if (thing == null) {
            return false;
        }
        String t = thing.trim().toLowerCase(Locale.ROOT);
        int at = t.indexOf('@');
        if (at > 0) {
            t = t.substring(0, at);
        }
        return t.length() >= 3 && lowerPassword.contains(t);
    }

    static int evaluate(String password, String name, String email) {
        String p = password == null ? "" : password;
        if (p.length() < 6) {
            return VERY_WEAK;
        }
        String lower = p.toLowerCase(Locale.ROOT);
        if (COMMON_SET.contains(lower) || allSame(p) || isRun(lower) || keyboardRun(lower)) {
            return VERY_WEAK;
        }
        boolean hasLower = false;
        boolean hasUpper = false;
        boolean hasDigit = false;
        boolean hasSymbol = false;
        boolean hasOther = false;
        HashSet<Character> distinct = new HashSet<Character>();
        for (int i = 0; i < p.length(); i++) {
            char c = p.charAt(i);
            distinct.add(c);
            if (c >= 'a' && c <= 'z') {
                hasLower = true;
            } else if (c >= 'A' && c <= 'Z') {
                hasUpper = true;
            } else if (c >= '0' && c <= '9') {
                hasDigit = true;
            } else if (c < 128) {
                hasSymbol = true;
            } else {
                hasOther = true;
            }
        }
        int pool = (hasLower ? 26 : 0) + (hasUpper ? 26 : 0) + (hasDigit ? 10 : 0)
                + (hasSymbol ? 33 : 0) + (hasOther ? 40 : 0);
        double bits = p.length() * (Math.log(pool) / Math.log(2));
        if (distinct.size() * 3 <= p.length()) {
            bits *= 0.5; // mostly repeated characters
        }
        int level;
        if (p.length() < 8 || bits < 28) {
            level = WEAK;
        } else if (bits < 40) {
            level = OK;
        } else if (bits < 60) {
            level = GOOD;
        } else {
            level = STRONG;
        }
        // habits that attackers try first
        if (p.matches("[A-Za-z]+[0-9]{1,4}") || p.matches("[0-9]+") || p.matches("[A-Za-z]+")) {
            level = Math.min(level, p.length() >= 14 ? GOOD : OK);
        }
        for (String w : BAD_WORDS) {
            if (lower.contains(w)) {
                level = Math.min(level, WEAK);
            }
        }
        if (mentions(lower, name) || mentions(lower, email)) {
            level = Math.min(level, WEAK);
        }
        return level;
    }
}
