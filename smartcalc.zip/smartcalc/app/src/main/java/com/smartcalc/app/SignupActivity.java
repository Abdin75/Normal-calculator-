package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

/**
 * The hidden signup page: part of a puzzle. It looks like a real form but NOTHING is saved or
 * sent anywhere: the password is checked in memory, a sarcastic verdict is shown, and the field is wiped.
 */
public class SignupActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int[] MESSAGES = {R.array.pw_msg_0, R.array.pw_msg_1, R.array.pw_msg_2,
            R.array.pw_msg_3, R.array.pw_msg_4};
    private static final int[] COLORS = {0xFFEF5350, 0xFFFF7043, 0xFFFFCA28, 0xFF9CCC65, 0xFF66BB6A};

    private final Random rnd = new Random();
    private Store store;
    private Puzzles puzzles;
    private Sfx sfx;
    private float dp;
    private EditText nameEt;
    private EditText emailEt;
    private EditText passEt;
    private TextView strength;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        sfx = new Sfx(this);
        if (!store.has(Puzzles.HIDDEN_PAGE)) {
            finish();
            return;
        }
        build();
    }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private EditText field(String hint, int inputType) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setSingleLine(true);
        et.setTextColor(0xFFFFFFFF);
        et.setHintTextColor(0xFF607D8B);
        et.setInputType(inputType);
        et.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        return et;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.page());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * dp);
        box.setPadding(pad, pad, pad, pad * 2);
        sv.addView(box);

        TextView title = tv("\uD83D\uDD10 " + getString(R.string.signup_title), 24, Ui.ACCENT);
        title.setPadding(0, 0, 0, (int) (8 * dp));
        box.addView(title);

        TextView warn = tv(getString(R.string.signup_note), 13, 0xFFFFB74D);
        warn.setBackground(Ui.round(0x33FFB74D, 10 * dp));
        int w = (int) (10 * dp);
        warn.setPadding(w, w, w, w);
        box.addView(warn, new LinearLayout.LayoutParams(MATCH, WRAP));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.card(dp));
        int p = (int) (14 * dp);
        card.setPadding(p, p, p, p);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(MATCH, WRAP);
        cl.setMargins(0, pad, 0, 0);
        box.addView(card, cl);

        nameEt = field(getString(R.string.signup_name), InputType.TYPE_CLASS_TEXT);
        emailEt = field(getString(R.string.signup_email), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        passEt = field(getString(R.string.signup_pass), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        card.addView(nameEt);
        card.addView(emailEt);
        card.addView(passEt);

        strength = tv("", 14, Ui.MUTED);
        strength.setPadding(0, (int) (6 * dp), 0, (int) (6 * dp));
        card.addView(strength);
        passEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() == 0) {
                    strength.setText("");
                    return;
                }
                int lvl = PasswordCheck.evaluate(s.toString(), nameEt.getText().toString(), emailEt.getText().toString());
                strength.setText(getString(R.string.signup_strength) + ": " + getResources().getStringArray(R.array.pw_levels)[lvl]);
                strength.setTextColor(COLORS[lvl]);
            }
        });

        CheckBox show = new CheckBox(this);
        show.setText(R.string.signup_show);
        show.setTextColor(Ui.TEXT);
        show.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                passEt.setTransformationMethod(checked ? HideReturnsTransformationMethod.getInstance()
                        : PasswordTransformationMethod.getInstance());
                passEt.setSelection(passEt.getText().length());
            }
        });
        card.addView(show);

        TextView go = new TextView(this);
        go.setText(R.string.signup_btn);
        go.setTextSize(16);
        go.setTextColor(0xFF1B1B1B);
        go.setGravity(Gravity.CENTER);
        go.setBackground(Ui.gradient(0xFFFFC107, 0xFFFF8F00, 14 * dp));
        go.setPadding(p, p, p, p);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submit();
            }
        });
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(MATCH, WRAP);
        gl.setMargins(0, (int) (10 * dp), 0, 0);
        card.addView(go, gl);
        setContentView(sv);
    }

    private void submit() {
        String pw = passEt.getText().toString();
        if (pw.length() == 0) {
            Toast.makeText(this, R.string.signup_empty, Toast.LENGTH_LONG).show();
            return;
        }
        int level = PasswordCheck.evaluate(pw, nameEt.getText().toString(), emailEt.getText().toString());
        passEt.setText("");   // wiped: it was only ever in memory
        String[] msgs = getResources().getStringArray(MESSAGES[level]);
        String text = msgs[rnd.nextInt(msgs.length)];
        String extra = null;
        if (level == PasswordCheck.VERY_WEAK) {
            extra = puzzles.solve(Puzzles.PW_WEAK);
            sfx.play(Sfx.SAD);
        } else if (level >= PasswordCheck.GOOD) {
            extra = puzzles.solve(Puzzles.PW_STRONG);
            sfx.play(Sfx.FANFARE);
        } else {
            sfx.play(Sfx.POP);
        }
        new AlertDialog.Builder(this).setMessage(extra != null ? text + "\n\n" + extra : text)
                .setPositiveButton(R.string.ok, null).show();
    }
}
