package com.smartcalc.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Puzzle maker (a paid feature): number puzzles with a message and a picture.
 * Everything is kept inside the app. "Export" turns them into text you can paste into arrays.xml
 * so they become part of the app itself for everybody.
 */
public class CreatorActivity extends Activity {

    private static final int REQ_IMG = 11;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Store store;
    private Entitlements ent;
    private Custom custom;
    private Sfx sfx;
    private float dp;
    private Uri picked;
    private TextView pickedLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        ent = new Entitlements(this, store);
        custom = new Custom(this);
        sfx = new Sfx(this);
        if (!store.has(Puzzles.KNOCK)) {
            finish();
            return;
        }
        if (!ent.has(Entitlements.PUZZLES)) {
            Toast.makeText(this, R.string.creator_locked, Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, ShopActivity.class));
            finish();
            return;
        }
        build();
    }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.card(dp));
        int p = (int) (14 * dp);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, 0, 0, (int) (12 * dp));
        parent.addView(c, lp);
        return c;
    }

    private TextView pill(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTextColor(Ui.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.gradient(0xFF3A2E6E, 0xFF2D2358, 14 * dp));
        int p = (int) (12 * dp);
        t.setPadding(p, p, p, p);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, (int) (6 * dp), 0, 0);
        t.setLayoutParams(lp);
        return t;
    }

    private EditText field(String hint, int inputType, int maxLen) {
        EditText et = new EditText(this);
        et.setHint(hint);
        et.setTextColor(0xFFFFFFFF);
        et.setHintTextColor(0xFF607D8B);
        et.setInputType(inputType);
        et.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        if (maxLen > 0) {
            et.setFilters(new android.text.InputFilter[] {new android.text.InputFilter.LengthFilter(maxLen)});
        }
        return et;
    }

    private static String xmlEsc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("'", "\\'").replace("\"", "\\\"").replace("\n", "\\n");
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.page());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (14 * dp);
        box.setPadding(pad, pad, pad, pad * 2);
        sv.addView(box);

        TextView title = tv("\uD83E\uDDE9 " + getString(R.string.creator_title), 26, Ui.ACCENT);
        title.setPadding(0, 0, 0, pad);
        box.addView(title);

        LinearLayout form = card(box);
        final EditText code = field(getString(R.string.creator_code), InputType.TYPE_CLASS_NUMBER, 12);
        final EditText msg = field(getString(R.string.creator_msg),
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE, 400);
        form.addView(code);
        form.addView(msg);
        pickedLabel = tv(picked != null ? "\u2714 " + getString(R.string.creator_pick) : "", 13, 0xFF81C784);
        form.addView(pill(getString(R.string.creator_pick), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("image/*");
                startActivityForResult(i, REQ_IMG);
            }
        }));
        form.addView(pickedLabel);
        form.addView(pill(getString(R.string.creator_save), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String digits = code.getText().toString().trim();
                String text = msg.getText().toString();
                String imageName = "";
                if (picked != null && digits.matches("[0-9]{2,12}")) {
                    String name = "cz_" + Norm.sha256Hex(digits).substring(0, 12);
                    if (MediaLib.savePrivateImage(CreatorActivity.this, picked, name)) {
                        imageName = name;
                    }
                }
                int r = custom.add(digits, text, imageName);
                if (r == 0) {
                    sfx.play(Sfx.COIN);
                    toast(getString(R.string.creator_saved));
                    picked = null;
                    build();
                } else {
                    sfx.play(Sfx.WRONG);
                    toast(getString(r == 2 ? R.string.creator_exists : (r == 3 ? R.string.creator_full : R.string.creator_bad)));
                }
            }
        }));

        final ArrayList<Custom.Item> items = custom.list();
        LinearLayout list = card(box);
        list.addView(tv(getString(R.string.creator_list) + "  (" + items.size() + " / " + Custom.MAX + ")", 16, Ui.TEXT));
        for (int i = 0; i < items.size(); i++) {
            final int idx = i;
            final Custom.Item it = items.get(i);
            String line = (it.digits == null || it.digits.length() == 0 ? "????" : it.digits) + "  \u2192  " + it.message;
            TextView t = tv(line, 14, 0xFFB0BEC5);
            t.setPadding(0, (int) (8 * dp), 0, 0);
            list.addView(t);
            list.addView(pill(getString(R.string.creator_delete), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (it.image != null && it.image.length() > 0) {
                        MediaLib.deletePrivateImage(CreatorActivity.this, it.image);
                    }
                    custom.remove(idx);
                    build();
                }
            }));
        }

        if (!items.isEmpty()) {
            LinearLayout ex = card(box);
            ex.addView(tv(getString(R.string.creator_export), 16, Ui.ACCENT));
            ex.addView(tv(getString(R.string.creator_export_note), 12, Ui.MUTED));
            StringBuilder d = new StringBuilder("extra_code_digits:\n");
            StringBuilder m = new StringBuilder("extra_code_messages:\n");
            for (Custom.Item it : items) {
                d.append("<item>").append(it.digits).append("</item>\n");
                m.append("<item>").append(xmlEsc(it.message)).append("</item>\n");
            }
            final String all = d.toString() + "\n" + m.toString();
            TextView out = tv(all, 12, 0xFF80CBC4);
            out.setTextIsSelectable(true);
            out.setTextDirection(View.TEXT_DIRECTION_LTR);
            ex.addView(out);
            ex.addView(pill(getString(R.string.creator_copy), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("smartcalc", all));
                    toast(getString(R.string.creator_copied));
                }
            }));
        }
        setContentView(sv);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_IMG && resultCode == RESULT_OK && data != null && data.getData() != null) {
            picked = data.getData();
            if (pickedLabel != null) {
                pickedLabel.setText("\u2714 " + getString(R.string.creator_pick));
            }
        }
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }
}
