package com.smartcalc.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

/** A meme card: a big emoji or number, a title and a caption. Drawn with code. */
final class GiftView extends View {

    private static final int[][] PALETTE = {
            {0xFF3949AB, 0xFF1A237E}, {0xFF00897B, 0xFF004D40}, {0xFFE53935, 0xFF8E0000},
            {0xFFFB8C00, 0xFFE65100}, {0xFF8E24AA, 0xFF4A148C}, {0xFF039BE5, 0xFF01579B},
            {0xFF43A047, 0xFF1B5E20}, {0xFFD81B60, 0xFF880E4F}, {0xFF5E35B1, 0xFF311B92},
            {0xFF546E7A, 0xFF263238}};

    private final String glyph;
    private final String title;
    private final String caption;
    private final int palette;
    private final boolean locked;
    private final String lockText;
    private final float dp;
    private final TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);

    GiftView(Context c, String glyph, String title, String caption, int palette,
             boolean locked, String lockText) {
        super(c);
        this.glyph = glyph;
        this.title = title;
        this.caption = caption;
        this.palette = Math.abs(palette) % PALETTE.length;
        this.locked = locked;
        this.lockText = lockText;
        dp = c.getResources().getDisplayMetrics().density;
    }

    private void paragraph(Canvas c, String text, float size, int color, float x, float y,
                           float width, int maxLines, boolean bold) {
        tp.setTextSize(size);
        tp.setColor(color);
        tp.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        StaticLayout l = StaticLayout.Builder.obtain(text, 0, text.length(), tp, (int) width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setMaxLines(maxLines)
                .setEllipsize(TextUtils.TruncateAt.END)
                .setTextDirection(TextDirectionHeuristics.FIRSTSTRONG_LTR)
                .build();
        c.save();
        c.translate(x, y);
        l.draw(c);
        c.restore();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        int top = locked ? 0xFF2A3050 : PALETTE[palette][0];
        int bottom = locked ? 0xFF161B30 : PALETTE[palette][1];
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[] {top, bottom});
        g.setCornerRadius(16 * dp);
        g.setBounds(0, 0, (int) w, (int) h);
        g.draw(c);
        float inner = w - 20 * dp;
        String big = locked ? "\uD83D\uDD12" : glyph;
        float gs = (big.length() > 3 ? 0.20f : 0.30f) * h;
        paragraph(c, big, gs, 0xFFFFFFFF, 10 * dp, 0.06f * h, inner, 1, false);
        if (locked) {
            paragraph(c, lockText, 12 * dp, 0xFFB0B8D8, 10 * dp, 0.50f * h, inner, 4, false);
            return;
        }
        paragraph(c, title, 14 * dp, 0xFFFFFFFF, 10 * dp, 0.50f * h, inner, 1, true);
        paragraph(c, caption, 11 * dp, 0xFFEAEAF5, 10 * dp, 0.62f * h, inner, 3, false);
    }
}
