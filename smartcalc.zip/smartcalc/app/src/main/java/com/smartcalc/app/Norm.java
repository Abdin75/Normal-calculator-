package com.smartcalc.app;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Hashing and Arabic text normalisation, so answers are never stored as plain text. */
final class Norm {

    private Norm() {
    }

    static String sha256Hex(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Removes marks, spaces and tatweel, and unifies alef / ya / ta marbuta forms. */
    static String arabic(String in) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < in.length(); i++) {
            char c = in.charAt(i);
            if (c >= '\u064B' && c <= '\u065F') {
                continue;
            }
            if (c == '\u0670' || c == '\u0640' || Character.isWhitespace(c)) {
                continue;
            }
            if (c == '\u0623' || c == '\u0625' || c == '\u0622' || c == '\u0671') {
                c = '\u0627';
            } else if (c == '\u0649') {
                c = '\u064A';
            } else if (c == '\u0629') {
                c = '\u0647';
            } else {
                c = Character.toLowerCase(c);
            }
            sb.append(c);
        }
        return sb.toString();
    }

    /** True if the normalised input hashes to one of the comma-separated hashes. */
    static boolean matches(String input, String hashesCsv) {
        String h = sha256Hex(arabic(input));
        for (String part : hashesCsv.split(",")) {
            if (h.equalsIgnoreCase(part.trim())) {
                return true;
            }
        }
        return false;
    }
}
