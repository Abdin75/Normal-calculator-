package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * The shop. "Pay" opens YOUR payment link in the browser; the buyer then types the unlock code
 * you send. Tapping the title nine times asks for the owner key (a hidden option for you only).
 */
public class ShopActivity extends Activity {

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private Store store;
    private Puzzles puzzles;
    private Entitlements ent;
    private Sfx sfx;
    private float dp;
    private int titleTaps;
    private long titleStart;
    private String pendingMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        ent = new Entitlements(this, store);
        sfx = new Sfx(this);
        if (!store.has(Puzzles.KNOCK)) {
            finish();
            return;
        }
        pendingMsg = puzzles.solve(Puzzles.SHOP_VISIT);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!store.has(Puzzles.KNOCK)) {
            return;
        }
        store.refresh();
        build();
        if (pendingMsg != null) {
            sfx.play(Sfx.SOLVE);
            new AlertDialog.Builder(this).setMessage(pendingMsg).setPositiveButton(R.string.ok, null).show();
            pendingMsg = null;
        }
    }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.card(dp));
        int p = (int) (14 * dp);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, 0, 0, (int) (12 * dp));
        parent.addView(c, lp);
        return c;
    }

    private TextView pill(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTextColor(Ui.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.gradient(0xFF3A2E6E, 0xFF2D2358, 14 * dp));
        int p = (int) (12 * dp);
        t.setPadding(p, p, p, p);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, (int) (6 * dp), 0, 0);
        t.setLayoutParams(lp);
        return t;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.page());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (14 * dp);
        box.setPadding(pad, pad, pad, pad * 2);
        sv.addView(box);

        TextView title = tv("\uD83D\uDED2 " + getString(R.string.shop_title), 26, Ui.ACCENT);
        title.setPadding(0, 0, 0, (int) (6 * dp));
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onTitleTap();
            }
        });
        box.addView(title);
        TextView note = tv(getString(R.string.shop_note), 13, Ui.MUTED);
        note.setPadding(0, 0, 0, pad);
        box.addView(note);

        for (int p = 0; p < Entitlements.PRODUCTS; p++) {
            final int product = p;
            LinearLayout c = card(box);
            c.addView(tv(ent.name(p), 18, Ui.ACCENT));
            c.addView(tv(ent.desc(p), 14, Ui.TEXT));
            c.addView(tv(ent.price(p), 16, 0xFF80CBC4));
            if (ent.has(p)) {
                c.addView(tv("\u2714 " + getString(R.string.shop_owned), 15, 0xFF81C784));
            } else if (ent.link(p).length() == 0) {
                c.addView(tv(getString(R.string.shop_nolink), 13, Ui.MUTED));
            } else {
                c.addView(pill(getString(R.string.shop_pay) + "  " + ent.price(p), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        openLink(ent.link(product));
                    }
                }));
            }
        }

        LinearLayout codeCard = card(box);
        final EditText code = new EditText(this);
        code.setHint(R.string.shop_code_hint);
        code.setSingleLine(true);
        code.setTextColor(0xFFFFFFFF);
        code.setHintTextColor(0xFF607D8B);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        codeCard.addView(code);
        codeCard.addView(pill(getString(R.string.shop_code_try), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int p = ent.tryCode(code.getText().toString());
                if (p >= 0) {
                    sfx.play(Sfx.COIN);
                    Toast.makeText(ShopActivity.this, R.string.shop_code_ok, Toast.LENGTH_LONG).show();
                    build();
                } else {
                    sfx.play(Sfx.WRONG);
                    Toast.makeText(ShopActivity.this, R.string.shop_code_bad, Toast.LENGTH_LONG).show();
                }
            }
        }));

        if (ent.owner()) {
            LinearLayout oc = card(box);
            oc.addView(tv("\uD83D\uDD11 " + getString(R.string.shop_owner_ok), 14, 0xFF81C784));
            oc.addView(pill(getString(R.string.shop_owner_panel), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(ShopActivity.this, OwnerActivity.class));
                }
            }));
        }
        setContentView(sv);
    }

    private void openLink(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, url, Toast.LENGTH_LONG).show();
        }
    }

    /** Nine quick taps on the title: a hidden door that only the owner key opens. */
    private void onTitleTap() {
        long now = SystemClock.uptimeMillis();
        if (titleTaps == 0 || now - titleStart > 6000) {
            titleTaps = 0;
            titleStart = now;
        }
        titleTaps++;
        if (titleTaps < 9) {
            return;
        }
        titleTaps = 0;
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        et.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO);
        new AlertDialog.Builder(this).setTitle(R.string.shop_owner_title).setView(et)
                .setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (ent.checkOwnerKey(et.getText().toString())) {
                            sfx.play(Sfx.FANFARE);
                            Toast.makeText(ShopActivity.this, R.string.shop_owner_ok, Toast.LENGTH_LONG).show();
                            build();
                        } else {
                            sfx.play(Sfx.WRONG);
                            Toast.makeText(ShopActivity.this, R.string.shop_owner_bad, Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton(R.string.close, null).show();
    }
}
