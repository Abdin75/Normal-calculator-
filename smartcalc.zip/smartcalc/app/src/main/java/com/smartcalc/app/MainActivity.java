package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;
import java.util.TimeZone;

/** Looks like an ordinary calculator. It is not. */
public class MainActivity extends Activity {

    private static final String PKG_MOUSE = "com.minimouse.app";
    private static final String PKG_KEYS = "com.minikeys.app";
    private static final String PKG_WEB = "com.floatweb.app";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    private static final int TREASURE_FIRST = 83;
    private static final int TREASURE_LAST = 92;

    private final CalcState state = new CalcState();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final ArrayList<String> history = new ArrayList<String>();
    private final ArrayList<String[]> queue = new ArrayList<String[]>();
    private final ArrayList<KeyButton> menuKeys = new ArrayList<KeyButton>();
    private final long[] presses = new long[15];
    private int pressCount;

    private Store store;
    private Puzzles puzzles;
    private Custom custom;
    private Sfx sfx;
    private float dp;
    private TextView exprLine;
    private TextView resultLine;
    private TextView banner;
    private TextView note;
    private boolean bannerBusy;
    private boolean mouseMode;
    private boolean fortuneFired;
    private int knocks;
    private long knockStart;
    private int titleTaps;
    private long titleStart;
    private int emptyEquals;
    private long emptyStart;
    private int resultsShown;

    private final Runnable nextBannerRunnable = new Runnable() {
        @Override
        public void run() {
            nextBanner();
        }
    };

    private final Runnable fortuneRunnable = new Runnable() {
        @Override
        public void run() {
            fortuneFired = true;
            showFortune();
        }
    };

    private final Runnable spontaneous = new Runnable() {
        @Override
        public void run() {
            if (!bannerBusy) {
                showNote(rnd.nextBoolean() ? humanNote() : clueNote());
            }
            scheduleSpontaneous();
        }
    };

    // ------------------------------------------------------------------ keys

    private final class KeyButton extends TextView {
        Runnable onClick;
        Runnable onLong;
        long longMs = 600;
        private boolean longFired;
        private boolean cancelled;
        private final Runnable fireLong = new Runnable() {
            @Override
            public void run() {
                if (onLong != null) {
                    longFired = true;
                    onLong.run();
                }
            }
        };

        KeyButton(Context c, String label, int top, int bottom, int fg) {
            super(c);
            setText(label);
            setTextColor(fg);
            setTextSize(24);
            setGravity(Gravity.CENTER);
            setBackground(Ui.gradient(top, bottom, 20 * dp));
        }

        private void pressed(boolean on) {
            setAlpha(on ? 0.78f : 1f);
            setScaleX(on ? 0.95f : 1f);
            setScaleY(on ? 0.95f : 1f);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    longFired = false;
                    cancelled = false;
                    pressed(true);
                    if (onLong != null) {
                        postDelayed(fireLong, longMs);
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!cancelled && (e.getX() < 0 || e.getY() < 0
                            || e.getX() > getWidth() || e.getY() > getHeight())) {
                        cancelled = true;
                        removeCallbacks(fireLong);
                        pressed(false);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    removeCallbacks(fireLong);
                    pressed(false);
                    if (!cancelled && !longFired && onClick != null) {
                        playSoundEffect(SoundEffectConstants.CLICK);
                        onClick.run();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    removeCallbacks(fireLong);
                    pressed(false);
                    return true;
                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        custom = new Custom(this);
        sfx = new Sfx(this);
        buildUi();
        refresh();

        int launches = store.bump("launch");
        if (launches >= 10) {
            award(Puzzles.LAUNCH10);
        }
        if (launches >= 50) {
            award(Puzzles.LAUNCH50);
        }
        if (launches >= 100) {
            award(Puzzles.LAUNCH100);
        }
        updateStreak();
        if (launches > 2 && rnd.nextInt(3) == 0) {
            showNote(rnd.nextBoolean() ? humanNote() : clueNote());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        store.refresh();
        mouseMode = Ctx.accessibilityOn(this, PKG_MOUSE);
        applyMouseMode();
        if (store.tampered) {
            store.tampered = false;
            showBanner(getString(R.string.tamper_msg));
        }
        checkEnvironment();
        scheduleSpontaneous();
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(spontaneous);
        ui.removeCallbacks(fortuneRunnable);
    }

    private void scheduleSpontaneous() {
        ui.removeCallbacks(spontaneous);
        ui.postDelayed(spontaneous, 70000 + rnd.nextInt(140000));
    }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackground(Ui.page());
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        root.addView(main, new FrameLayout.LayoutParams(MATCH, MATCH));

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("Smart Calc", 18, Ui.TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding((int) (18 * dp), 0, 0, 0);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onTitleTap();
            }
        });
        top.addView(title, new LinearLayout.LayoutParams(0, MATCH, 1f));
        TextView hist = tv(getString(R.string.history_title), 14, Ui.MUTED);
        hist.setPadding((int) (12 * dp), 0, (int) (12 * dp), 0);
        hist.setGravity(Gravity.CENTER_VERTICAL);
        hist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHistory();
            }
        });
        top.addView(hist, new LinearLayout.LayoutParams(WRAP, MATCH));
        TextView about = tv(getString(R.string.about_title), 14, Ui.MUTED);
        about.setPadding((int) (12 * dp), 0, (int) (18 * dp), 0);
        about.setGravity(Gravity.CENTER_VERTICAL);
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAbout();
            }
        });
        top.addView(about, new LinearLayout.LayoutParams(WRAP, MATCH));
        main.addView(top, new LinearLayout.LayoutParams(MATCH, (int) (52 * dp)));

        // display card. Seven quick taps open the secret door; a long press asks the fortune teller.
        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        display.setGravity(Gravity.BOTTOM | Gravity.END);
        display.setBackground(Ui.card(dp));
        display.setPadding((int) (20 * dp), (int) (10 * dp), (int) (20 * dp), (int) (14 * dp));
        exprLine = new TextView(this);
        exprLine.setTextSize(18);
        exprLine.setTextColor(Ui.MUTED);
        exprLine.setSingleLine(true);
        exprLine.setEllipsize(TextUtils.TruncateAt.START);
        exprLine.setGravity(Gravity.END);
        display.addView(exprLine, new LinearLayout.LayoutParams(MATCH, WRAP));
        resultLine = new TextView(this);
        resultLine.setTextSize(44);
        resultLine.setTextColor(0xFFFFFFFF);
        resultLine.setSingleLine(true);
        resultLine.setEllipsize(TextUtils.TruncateAt.START);
        resultLine.setGravity(Gravity.END);
        display.addView(resultLine, new LinearLayout.LayoutParams(MATCH, WRAP));
        display.setOnTouchListener(new View.OnTouchListener() {
            private float x0;
            private float y0;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        x0 = e.getX();
                        y0 = e.getY();
                        fortuneFired = false;
                        ui.postDelayed(fortuneRunnable, 1500);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getX() - x0) > 12 * dp || Math.abs(e.getY() - y0) > 12 * dp) {
                            ui.removeCallbacks(fortuneRunnable);
                        }
                        return true;
                    case MotionEvent.ACTION_UP: {
                        ui.removeCallbacks(fortuneRunnable);
                        if (fortuneFired) {
                            return true;
                        }
                        float dx = e.getX() - x0;
                        float dy = e.getY() - y0;
                        if (Math.abs(dx) < 12 * dp && Math.abs(dy) < 12 * dp) {
                            onDisplayTap();
                        } else if (dx < -60 * dp && Math.abs(dy) < 80 * dp) {
                            onSwipeLeft();
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_CANCEL:
                        ui.removeCallbacks(fortuneRunnable);
                        return true;
                    default:
                        return true;
                }
            }
        });
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(MATCH, 0, 1.1f);
        int dm = (int) (12 * dp);
        dl.setMargins(dm, 0, dm, dm);
        main.addView(display, dl);

        // keypad
        String[][] labels = {
                {"C", "( )", "%", "\u00f7"},
                {"7", "8", "9", "\u00d7"},
                {"4", "5", "6", "\u2212"},
                {"1", "2", "3", "+"},
                {"0", ".", "\u2190", "="}};
        String[][] codes = {
                {"C", "()", "%", "/"},
                {"7", "8", "9", "*"},
                {"4", "5", "6", "-"},
                {"1", "2", "3", "+"},
                {"0", ".", "DEL", "="}};
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding((int) (8 * dp), 0, (int) (8 * dp), (int) (8 * dp));
        for (int r = 0; r < 5; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < 4; k++) {
                KeyButton b = makeKey(labels[r][k], codes[r][k]);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
                int m = (int) (4 * dp);
                lp.setMargins(m, m, m, m);
                row.addView(b, lp);
            }
            pad.addView(row, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        }
        main.addView(pad, new LinearLayout.LayoutParams(MATCH, 0, 2.6f));

        // message banner and sticky note
        View.OnClickListener skip = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ui.removeCallbacks(nextBannerRunnable);
                nextBanner();
            }
        };
        banner = tv("", 15, 0xFFFFFFFF);
        banner.setBackground(Ui.card(dp));
        banner.setPadding((int) (14 * dp), (int) (10 * dp), (int) (14 * dp), (int) (10 * dp));
        banner.setVisibility(View.GONE);
        banner.setOnClickListener(skip);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP);
        bl.setMargins((int) (12 * dp), (int) (56 * dp), (int) (12 * dp), 0);
        root.addView(banner, bl);

        note = tv("", 15, 0xFF3E2723);
        note.setBackground(Ui.round(0xFFFFF59D, 6 * dp));
        note.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
        note.setPadding((int) (16 * dp), (int) (12 * dp), (int) (16 * dp), (int) (12 * dp));
        note.setRotation(-1.5f);
        note.setElevation(6 * dp);
        note.setVisibility(View.GONE);
        note.setOnClickListener(skip);
        FrameLayout.LayoutParams nl = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP);
        nl.setMargins((int) (18 * dp), (int) (58 * dp), (int) (18 * dp), 0);
        root.addView(note, nl);

        setContentView(root);
    }

    private KeyButton makeKey(String label, final String code) {
        boolean op = code.equals("/") || code.equals("*") || code.equals("-") || code.equals("+")
                || code.equals("%") || code.equals("()");
        int top;
        int bottom;
        int fg;
        if (code.equals("=")) {
            top = 0xFFFFC107;
            bottom = 0xFFFF8F00;
            fg = 0xFF1B1B1B;
        } else if (code.equals("C")) {
            top = 0xFF4A2433;
            bottom = 0xFF3A1B28;
            fg = 0xFFFF6B7A;
        } else if (op) {
            top = 0xFF3A2E6E;
            bottom = 0xFF2D2358;
            fg = 0xFFFFCA28;
        } else {
            top = 0xFF2B3354;
            bottom = 0xFF222947;
            fg = 0xFFFFFFFF;
        }
        KeyButton b = new KeyButton(this, label, top, bottom, fg);
        b.onClick = new Runnable() {
            @Override
            public void run() {
                onKey(code);
            }
        };
        if (code.equals("=")) {
            b.longMs = 2000;
            b.onLong = new Runnable() {
                @Override
                public void run() {
                    award(Puzzles.HOLD_EQ);
                }
            };
        } else if (code.equals("C")) {
            b.longMs = 800;
            b.onLong = new Runnable() {
                @Override
                public void run() {
                    onKey("C");
                    award(Puzzles.HOLD_C);
                }
            };
        } else if (!code.equals("DEL")) {
            menuKeys.add(b);
        }
        return b;
    }

    // ------------------------------------------------------------------ calculator

    private static String pretty(String s) {
        return s.replace('*', '\u00d7').replace('/', '\u00f7').replace('-', '\u2212');
    }

    private void refresh() {
        String e = state.expression();
        String pv = state.preview();
        String big;
        String small;
        if (state.isFresh()) {
            big = state.result();
            small = pretty(state.lastExpr) + " =";
        } else {
            big = pv.length() > 0 ? pv : (e.length() == 0 ? "0" : pretty(e));
            small = pv.length() > 0 ? pretty(e) : "";
        }
        exprLine.setText(small);
        resultLine.setText(big);
        int len = big.length();
        resultLine.setTextSize(len <= 9 ? 44 : (len <= 13 ? 34 : (len <= 18 ? 26 : 20)));
    }

    private void trackFastHands() {
        long now = SystemClock.uptimeMillis();
        presses[pressCount % presses.length] = now;
        pressCount++;
        if (pressCount >= presses.length) {
            long oldest = presses[pressCount % presses.length];
            if (now - oldest < 3000) {
                award(Puzzles.FAST_HANDS);
            }
        }
    }

    private void onKey(String key) {
        trackFastHands();
        state.press(key);
        refresh();
        if (state.emptyEquals) {
            long now = SystemClock.uptimeMillis();
            if (emptyEquals == 0 || now - emptyStart > 8000) {
                emptyEquals = 0;
                emptyStart = now;
            }
            emptyEquals++;
            if (emptyEquals >= 10) {
                emptyEquals = 0;
                award(Puzzles.EQ_SPAM);
            } else if (emptyEquals % 3 == 0) {
                quip(R.array.quips_empty);
            }
        }
        if (state.expression().equals("0000000000")) {
            award(Puzzles.ZEROS);
        }
        if (state.evaluated) {
            afterEvaluate();
        }
    }

    private void afterEvaluate() {
        String ex = state.lastExpr;
        String res = state.result();
        history.add(0, pretty(ex) + " = " + res);
        while (history.size() > 20) {
            history.remove(history.size() - 1);
        }
        if (state.error) {
            if (state.divZero && ex.equals("0/0")) {
                award(Puzzles.ZERO_DIV);
            } else {
                int eid = puzzles.matchExpr(ex, res);
                if (eid >= 0) {
                    award(eid);
                } else if (rnd.nextInt(2) == 0) {
                    quip(R.array.quips_error);
                    sfx.play(Sfx.WRONG);
                }
            }
            return;
        }
        int calcs = store.bump("calcs");
        if (calcs >= 50) {
            award(Puzzles.CALC50);
        }
        if (calcs >= 200) {
            award(Puzzles.CALC200);
        }
        if (calcs >= 1000) {
            award(Puzzles.CALC1000);
        }
        if (res.equals("0.30000000000000004")) {
            award(Puzzles.FLOAT);
        }
        if (res.equals("1") && (ex.equals("1/3*3") || ex.equals("(1/3)*3") || ex.equals("3*(1/3)"))) {
            award(Puzzles.THIRD);
        }
        int eid = puzzles.matchExpr(ex, res);
        if (eid >= 0) {
            award(eid);
        }
        if (ex.length() >= 2 && ex.matches("[0-9]+")) {
            int id = puzzles.matchCode(ex);
            if (id >= 0) {
                award(id);
                if (id == Puzzles.HIDDEN_PAGE) {
                    startActivity(new Intent(this, SignupActivity.class));
                }
            } else {
                String baked = puzzles.baked(ex);
                Custom.Item mine = baked == null ? custom.match(ex) : null;
                if (baked != null) {
                    showNote(baked);
                    sfx.play(Sfx.SECRET);
                } else if (mine != null) {
                    showCustom(mine);
                }
            }
        }
        resultsShown++;
        if (resultsShown >= 4 && rnd.nextInt(12) == 0) {
            quip(R.array.quips_random);
        }
        if (resultsShown % 15 == 0 && rnd.nextInt(3) == 0) {
            showNote(humanNote());
        }
    }

    // ------------------------------------------------------------------ secrets

    private void onDisplayTap() {
        int taps = store.bump("taps");
        if (taps >= 67) {
            award(Puzzles.TAP67);
        }
        long now = SystemClock.uptimeMillis();
        if (knocks == 0 || now - knockStart > 4000) {
            knocks = 0;
            knockStart = now;
        }
        knocks++;
        if (knocks >= 7) {
            knocks = 0;
            Intent i = new Intent(this, VaultActivity.class);
            String m = puzzles.solve(Puzzles.KNOCK);
            if (m != null) {
                i.putExtra("msg", m);
                sfx.play(Sfx.SOLVE);
            }
            startActivity(i);
        }
    }

    private void onSwipeLeft() {
        onKey("DEL");
        if (store.bump("swipes") >= 10) {
            award(Puzzles.SWIPE10);
        }
    }

    /** My own secret: hold the result for a second and a half and the fortune teller wakes up. */
    private void showFortune() {
        String[] f = getResources().getStringArray(R.array.fortunes);
        int times = store.bump("fortunes");
        int seed = (state.result() + "|" + state.expression()).hashCode() ^ (int) (System.currentTimeMillis() / 60000L);
        String msg;
        if (times == 1) {
            msg = getString(R.string.fortune_first);
        } else if (times % 7 == 0) {
            msg = getString(R.string.fortune_tired);
        } else {
            int lucky = 1 + Math.abs(seed / 7) % 99;
            msg = f[Math.abs(seed) % f.length] + "\n\n" + getString(R.string.fortune_lucky) + ": " + lucky;
        }
        sfx.play(Sfx.SECRET);
        new AlertDialog.Builder(this).setTitle("\uD83D\uDD2E " + getString(R.string.fortune_title))
                .setMessage(msg).setPositiveButton(R.string.ok, null).show();
    }

    private void onTitleTap() {
        long now = SystemClock.uptimeMillis();
        if (titleTaps == 0 || now - titleStart > 3000) {
            titleTaps = 0;
            titleStart = now;
        }
        titleTaps++;
        if (titleTaps >= 5) {
            titleTaps = 0;
            String m = puzzles.solve(Puzzles.VERSION);
            showBanner(m != null ? m : getString(R.string.version_line));
        }
    }

    private void applyMouseMode() {
        for (KeyButton k : menuKeys) {
            k.onLong = mouseMode ? new Runnable() {
                @Override
                public void run() {
                    showContextMenu();
                }
            } : null;
        }
    }

    /** Only appears while the mouse app is on: a tiny right-click menu, parody edition. */
    private void showContextMenu() {
        final String[] items = getResources().getStringArray(R.array.context_menu_items);
        final String[] replies = getResources().getStringArray(R.array.context_menu_replies);
        new AlertDialog.Builder(this)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which >= 0 && which < replies.length) {
                            showBanner(replies[which]);
                        }
                        if (which == items.length - 1 && mouseMode) {
                            award(Puzzles.RIGHT_MENU);
                        }
                    }
                })
                .show();
    }

    private void updateStreak() {
        long now = System.currentTimeMillis();
        int day = (int) ((now + TimeZone.getDefault().getOffset(now)) / 86400000L);
        int last = store.get("last_day");
        if (day == last) {
            return;
        }
        int streak = (day == last + 1) ? store.get("streak") + 1 : 1;
        store.put("last_day", day);
        store.put("streak", streak);
        if (streak >= 3) {
            award(Puzzles.STREAK3);
        }
        if (streak >= 7) {
            award(Puzzles.STREAK7);
        }
    }

    private void checkEnvironment() {
        Calendar cal = Calendar.getInstance();
        int h = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        if (h == 3) {
            award(Puzzles.NIGHT);
        }
        if (h == 5) {
            award(Puzzles.EARLYBIRD);
        }
        if (h == 0 && min == 0) {
            award(Puzzles.MIDNIGHT);
        }
        if ((h == 6 || h == 18) && min == 7) {
            award(Puzzles.TIME607);
        }
        if (month == Calendar.MARCH && day == 14) {
            award(Puzzles.PIDAY);
        }
        if (month == Calendar.APRIL && day == 1) {
            award(Puzzles.APRIL1);
        }
        if (month == Calendar.OCTOBER && day == 31) {
            award(Puzzles.HALLOWEEN);
        }
        if (month == Calendar.JANUARY && day == 1) {
            award(Puzzles.NEWYEAR);
        }
        if (day == 13 && cal.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) {
            award(Puzzles.FRI13);
        }
        if (cal.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY) {
            award(Puzzles.MONDAY);
        }
        if (Ctx.airplane(this)) {
            award(Puzzles.AIRPLANE);
        }
        int b = Ctx.batteryPercent(this);
        if (b >= 0 && b <= 10 && !Ctx.charging(this)) {
            award(Puzzles.LOW_BATT);
        }
        if (b == 42) {
            award(Puzzles.BATT42);
        }
        if (b == 67) {
            award(Puzzles.BATT67);
        }
        boolean keys = Ctx.imeSelected(this, PKG_KEYS);
        boolean web = Ctx.installed(this, PKG_WEB);
        if (mouseMode) {
            award(Puzzles.MOUSE);
        }
        if (keys) {
            award(Puzzles.KEYS);
        }
        if (web) {
            award(Puzzles.FLOATWEB);
        }
        if (mouseMode && keys && web) {
            award(Puzzles.TRILOGY);
        }
        if (Ctx.totalMem(this) < 2600000000L) {
            award(Puzzles.LOW_RAM);
        }
    }

    private void award(int id) {
        String m = puzzles.solve(id);
        if (m != null) {
            showBanner(m);
            if (id == Puzzles.FINALE) {
                sfx.play(Sfx.FANFARE);
            } else if (id >= TREASURE_FIRST && id <= TREASURE_LAST) {
                sfx.play(Sfx.SECRET);
            } else {
                sfx.play(Sfx.SOLVE);
            }
        }
    }

    // ------------------------------------------------------------------ messages that feel handwritten

    private String humanNote() {
        String[] a = getResources().getStringArray(R.array.quips_human);
        return "\uD83D\uDCDD " + a[rnd.nextInt(a.length)];
    }

    /** A hint of a puzzle you have not solved yet, wrapped like something somebody scribbled. */
    private String clueNote() {
        for (int tries = 0; tries < 30; tries++) {
            int id = rnd.nextInt(Puzzles.COUNT);
            boolean secretCode = id >= TREASURE_FIRST && id <= TREASURE_LAST;
            if (puzzles.solved(id) || secretCode || id == Puzzles.FINALE || id == Puzzles.KNOCK) {
                continue;
            }
            String[] w = getResources().getStringArray(R.array.note_wrappers);
            return "\uD83D\uDCDD " + w[rnd.nextInt(w.length)].replace("{h}", puzzles.hint(id));
        }
        return humanNote();
    }

    private void showCustom(Custom.Item it) {
        sfx.play(Sfx.COIN);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * dp);
        box.setPadding(pad, pad, pad, 0);
        box.addView(tv(it.message, 16, 0xFFFFFFFF));
        if (it.image != null && it.image.length() > 0) {
            Bitmap b = MediaLib.loadPrivateImage(this, it.image, 900);
            if (b != null) {
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(b);
                iv.setAdjustViewBounds(true);
                iv.setPadding(0, pad, 0, 0);
                box.addView(iv);
            }
        }
        new AlertDialog.Builder(this).setTitle(R.string.custom_solved).setView(box)
                .setPositiveButton(R.string.ok, null).show();
    }

    // ------------------------------------------------------------------ banner and dialogs

    private void quip(int arrayRes) {
        String[] a = getResources().getStringArray(arrayRes);
        showBanner(a[rnd.nextInt(a.length)]);
    }

    private void showBanner(String msg) {
        enqueue("0", msg);
    }

    private void showNote(String msg) {
        enqueue("1", msg);
    }

    private void enqueue(String type, String msg) {
        queue.add(new String[] {type, msg});
        if (!bannerBusy) {
            nextBanner();
        }
    }

    private void nextBanner() {
        banner.setVisibility(View.GONE);
        note.setVisibility(View.GONE);
        if (queue.isEmpty()) {
            bannerBusy = false;
            return;
        }
        bannerBusy = true;
        String[] q = queue.remove(0);
        TextView t = q[0].equals("1") ? note : banner;
        t.setText(q[1]);
        t.setVisibility(View.VISIBLE);
        ui.postDelayed(nextBannerRunnable, Math.min(9000, 2500 + q[1].length() * 55));
    }

    private void showHistory() {
        StringBuilder sb = new StringBuilder(getString(R.string.history_top)).append("\n\n");
        if (history.isEmpty()) {
            sb.append(getString(R.string.history_empty));
        } else {
            for (String h : history) {
                sb.append(h).append('\n');
            }
        }
        new AlertDialog.Builder(this).setTitle(R.string.history_title).setMessage(sb.toString())
                .setPositiveButton(R.string.ok, null).show();
    }

    private void showAbout() {
        String[] clues = getResources().getStringArray(R.array.about_clues);
        int n = store.bump("about");
        String clue = clues[Math.min(n - 1, clues.length - 1)];
        new AlertDialog.Builder(this).setTitle(R.string.about_title)
                .setMessage(getString(R.string.about_body) + "\n\n" + clue)
                .setPositiveButton(R.string.ok, null).show();
    }
}
