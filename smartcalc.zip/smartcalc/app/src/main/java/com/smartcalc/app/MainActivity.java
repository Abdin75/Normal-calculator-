package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

/** Looks like an ordinary calculator. It is not. */
public class MainActivity extends Activity {

    private static final String PKG_MOUSE = "com.minimouse.app";
    private static final String PKG_KEYS = "com.minikeys.app";
    private static final String PKG_WEB = "com.floatweb.app";
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final CalcState state = new CalcState();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final ArrayList<String> history = new ArrayList<String>();
    private final ArrayList<String> queue = new ArrayList<String>();
    private final ArrayList<KeyButton> menuKeys = new ArrayList<KeyButton>();
    private final long[] presses = new long[15];
    private int pressCount;

    private Store store;
    private Puzzles puzzles;
    private float dp;
    private TextView exprLine;
    private TextView resultLine;
    private TextView banner;
    private boolean bannerBusy;
    private boolean mouseMode;
    private int knocks;
    private long knockStart;
    private int titleTaps;
    private long titleStart;
    private int emptyEquals;
    private long emptyStart;
    private int resultsShown;

    private final Runnable nextBannerRunnable = new Runnable() {
        @Override
        public void run() {
            nextBanner();
        }
    };

    // ------------------------------------------------------------------ keys

    private final class KeyButton extends TextView {
        Runnable onClick;
        Runnable onLong;
        long longMs = 600;
        private boolean longFired;
        private boolean cancelled;
        private final Runnable fireLong = new Runnable() {
            @Override
            public void run() {
                if (onLong != null) {
                    longFired = true;
                    onLong.run();
                }
            }
        };

        KeyButton(Context c, String label, int bg, int fg) {
            super(c);
            setText(label);
            setTextColor(fg);
            setTextSize(24);
            setGravity(Gravity.CENTER);
            GradientDrawable g = new GradientDrawable();
            g.setColor(bg);
            g.setCornerRadius(18 * dp);
            setBackground(g);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    longFired = false;
                    cancelled = false;
                    setAlpha(0.6f);
                    if (onLong != null) {
                        postDelayed(fireLong, longMs);
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!cancelled && (e.getX() < 0 || e.getY() < 0
                            || e.getX() > getWidth() || e.getY() > getHeight())) {
                        cancelled = true;
                        removeCallbacks(fireLong);
                        setAlpha(1f);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    removeCallbacks(fireLong);
                    setAlpha(1f);
                    if (!cancelled && !longFired && onClick != null) {
                        onClick.run();
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    removeCallbacks(fireLong);
                    setAlpha(1f);
                    return true;
                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        buildUi();
        refresh();
        int launches = store.bump("launch");
        if (launches > 2 && rnd.nextInt(4) == 0) {
            quip(R.array.quips_launch);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        store.refresh();
        mouseMode = Ctx.accessibilityOn(this, PKG_MOUSE);
        applyMouseMode();
        if (store.tampered) {
            store.tampered = false;
            showBanner(getString(R.string.tamper_msg));
        }
        checkEnvironment();
    }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF121212);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        root.addView(main, new FrameLayout.LayoutParams(MATCH, MATCH));

        // top bar
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = tv("Smart Calc", 18, 0xFFB0BEC5);
        title.setPadding((int) (16 * dp), 0, 0, 0);
        title.setGravity(Gravity.CENTER_VERTICAL);
        title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onTitleTap();
            }
        });
        top.addView(title, new LinearLayout.LayoutParams(0, MATCH, 1f));
        TextView hist = tv(getString(R.string.history_title), 14, 0xFF78909C);
        hist.setPadding((int) (12 * dp), 0, (int) (12 * dp), 0);
        hist.setGravity(Gravity.CENTER_VERTICAL);
        hist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showHistory();
            }
        });
        top.addView(hist, new LinearLayout.LayoutParams(WRAP, MATCH));
        TextView about = tv(getString(R.string.about_title), 14, 0xFF78909C);
        about.setPadding((int) (12 * dp), 0, (int) (16 * dp), 0);
        about.setGravity(Gravity.CENTER_VERTICAL);
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAbout();
            }
        });
        top.addView(about, new LinearLayout.LayoutParams(WRAP, MATCH));
        main.addView(top, new LinearLayout.LayoutParams(MATCH, (int) (48 * dp)));

        // display: tapping it seven times is the secret door
        LinearLayout display = new LinearLayout(this);
        display.setOrientation(LinearLayout.VERTICAL);
        display.setGravity(Gravity.BOTTOM | Gravity.END);
        display.setPadding((int) (20 * dp), (int) (8 * dp), (int) (20 * dp), (int) (12 * dp));
        exprLine = new TextView(this);
        exprLine.setTextSize(18);
        exprLine.setTextColor(0xFF78909C);
        exprLine.setSingleLine(true);
        exprLine.setEllipsize(TextUtils.TruncateAt.START);
        exprLine.setGravity(Gravity.END);
        display.addView(exprLine, new LinearLayout.LayoutParams(MATCH, WRAP));
        resultLine = new TextView(this);
        resultLine.setTextSize(44);
        resultLine.setTextColor(0xFFFFFFFF);
        resultLine.setSingleLine(true);
        resultLine.setEllipsize(TextUtils.TruncateAt.START);
        resultLine.setGravity(Gravity.END);
        display.addView(resultLine, new LinearLayout.LayoutParams(MATCH, WRAP));
        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onKnock();
            }
        });
        main.addView(display, new LinearLayout.LayoutParams(MATCH, 0, 1.1f));

        // keypad
        String[][] labels = {
                {"C", "( )", "%", "\u00f7"},
                {"7", "8", "9", "\u00d7"},
                {"4", "5", "6", "\u2212"},
                {"1", "2", "3", "+"},
                {"0", ".", "\u2190", "="}};
        String[][] codes = {
                {"C", "()", "%", "/"},
                {"7", "8", "9", "*"},
                {"4", "5", "6", "-"},
                {"1", "2", "3", "+"},
                {"0", ".", "DEL", "="}};
        LinearLayout pad = new LinearLayout(this);
        pad.setOrientation(LinearLayout.VERTICAL);
        pad.setPadding((int) (8 * dp), 0, (int) (8 * dp), (int) (8 * dp));
        for (int r = 0; r < 5; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int k = 0; k < 4; k++) {
                KeyButton b = makeKey(labels[r][k], codes[r][k]);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, MATCH, 1f);
                int m = (int) (4 * dp);
                lp.setMargins(m, m, m, m);
                row.addView(b, lp);
            }
            pad.addView(row, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        }
        main.addView(pad, new LinearLayout.LayoutParams(MATCH, 0, 2.6f));

        // banner for messages
        banner = tv("", 15, 0xFFFFFFFF);
        GradientDrawable bb = new GradientDrawable();
        bb.setColor(0xF0263238);
        bb.setCornerRadius(14 * dp);
        bb.setStroke((int) (1.5f * dp), 0xFFFFB300);
        banner.setBackground(bb);
        banner.setPadding((int) (14 * dp), (int) (10 * dp), (int) (14 * dp), (int) (10 * dp));
        banner.setVisibility(View.GONE);
        banner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ui.removeCallbacks(nextBannerRunnable);
                nextBanner();
            }
        });
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP);
        bl.setMargins((int) (12 * dp), (int) (56 * dp), (int) (12 * dp), 0);
        root.addView(banner, bl);

        setContentView(root);
    }

    private KeyButton makeKey(String label, final String code) {
        boolean op = code.equals("/") || code.equals("*") || code.equals("-") || code.equals("+")
                || code.equals("%") || code.equals("()");
        int bg = code.equals("=") ? 0xFFFFB300 : (op ? 0xFF2B2B2B : 0xFF1F1F1F);
        int fg = code.equals("=") ? 0xFF121212
                : (code.equals("C") ? 0xFFEF5350 : (op ? 0xFFFFB300 : 0xFFFFFFFF));
        KeyButton b = new KeyButton(this, label, bg, fg);
        b.onClick = new Runnable() {
            @Override
            public void run() {
                onKey(code);
            }
        };
        if (code.equals("=")) {
            b.longMs = 2000;
            b.onLong = new Runnable() {
                @Override
                public void run() {
                    award(Puzzles.HOLD_EQ);
                }
            };
        } else if (code.equals("C")) {
            b.longMs = 800;
            b.onLong = new Runnable() {
                @Override
                public void run() {
                    onKey("C");
                    award(Puzzles.HOLD_C);
                }
            };
        } else if (!code.equals("DEL")) {
            menuKeys.add(b);
        }
        return b;
    }

    // ------------------------------------------------------------------ calculator

    private static String pretty(String s) {
        return s.replace('*', '\u00d7').replace('/', '\u00f7').replace('-', '\u2212');
    }

    private void refresh() {
        String e = state.expression();
        String pv = state.preview();
        String big;
        String small;
        if (state.isFresh()) {
            big = state.result();
            small = pretty(state.lastExpr) + " =";
        } else {
            big = pv.length() > 0 ? pv : (e.length() == 0 ? "0" : pretty(e));
            small = pv.length() > 0 ? pretty(e) : "";
        }
        exprLine.setText(small);
        resultLine.setText(big);
        int len = big.length();
        resultLine.setTextSize(len <= 9 ? 44 : (len <= 13 ? 34 : (len <= 18 ? 26 : 20)));
    }

    private void trackFastHands() {
        long now = SystemClock.uptimeMillis();
        presses[pressCount % presses.length] = now;
        pressCount++;
        if (pressCount >= presses.length) {
            long oldest = presses[pressCount % presses.length];
            if (now - oldest < 3000) {
                award(Puzzles.FAST_HANDS);
            }
        }
    }

    private void onKey(String key) {
        trackFastHands();
        state.press(key);
        refresh();
        if (state.emptyEquals) {
            long now = SystemClock.uptimeMillis();
            if (emptyEquals == 0 || now - emptyStart > 8000) {
                emptyEquals = 0;
                emptyStart = now;
            }
            emptyEquals++;
            if (emptyEquals >= 10) {
                emptyEquals = 0;
                award(Puzzles.EQ_SPAM);
            } else if (emptyEquals % 3 == 0) {
                quip(R.array.quips_empty);
            }
        }
        if (state.expression().equals("0000000000")) {
            award(Puzzles.ZEROS);
        }
        if (state.evaluated) {
            afterEvaluate();
        }
    }

    private void afterEvaluate() {
        String ex = state.lastExpr;
        String res = state.result();
        history.add(0, pretty(ex) + " = " + res);
        while (history.size() > 20) {
            history.remove(history.size() - 1);
        }
        if (state.error) {
            if (state.divZero && ex.equals("0/0")) {
                award(Puzzles.ZERO_DIV);
            } else if (rnd.nextInt(2) == 0) {
                quip(R.array.quips_error);
            }
            return;
        }
        if (res.equals("0.30000000000000004")) {
            award(Puzzles.FLOAT);
        }
        if (res.equals("1") && (ex.equals("1/3*3") || ex.equals("(1/3)*3") || ex.equals("3*(1/3)"))) {
            award(Puzzles.THIRD);
        }
        if (ex.length() >= 2 && ex.matches("[0-9]+")) {
            int id = puzzles.matchCode(ex);
            if (id >= 0) {
                award(id);
            }
        }
        resultsShown++;
        if (resultsShown >= 4 && rnd.nextInt(12) == 0) {
            quip(R.array.quips_random);
        }
    }

    // ------------------------------------------------------------------ secrets

    private void onKnock() {
        long now = SystemClock.uptimeMillis();
        if (knocks == 0 || now - knockStart > 4000) {
            knocks = 0;
            knockStart = now;
        }
        knocks++;
        if (knocks >= 7) {
            knocks = 0;
            Intent i = new Intent(this, VaultActivity.class);
            String m = puzzles.solve(Puzzles.KNOCK);
            if (m != null) {
                i.putExtra("msg", m);
            }
            startActivity(i);
        }
    }

    private void onTitleTap() {
        long now = SystemClock.uptimeMillis();
        if (titleTaps == 0 || now - titleStart > 3000) {
            titleTaps = 0;
            titleStart = now;
        }
        titleTaps++;
        if (titleTaps >= 5) {
            titleTaps = 0;
            String m = puzzles.solve(Puzzles.VERSION);
            showBanner(m != null ? m : getString(R.string.version_line));
        }
    }

    private void applyMouseMode() {
        for (KeyButton k : menuKeys) {
            k.onLong = mouseMode ? new Runnable() {
                @Override
                public void run() {
                    showContextMenu();
                }
            } : null;
        }
    }

    /** Only appears while the mouse app is on: a tiny right-click menu, parody edition. */
    private void showContextMenu() {
        final String[] items = getResources().getStringArray(R.array.context_menu_items);
        final String[] replies = getResources().getStringArray(R.array.context_menu_replies);
        new AlertDialog.Builder(this)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which >= 0 && which < replies.length) {
                            showBanner(replies[which]);
                        }
                        if (which == items.length - 1 && mouseMode) {
                            award(Puzzles.RIGHT_MENU);
                        }
                    }
                })
                .show();
    }

    private void checkEnvironment() {
        if (Ctx.hour() == 3) {
            award(Puzzles.NIGHT);
        }
        if (Ctx.airplane(this)) {
            award(Puzzles.AIRPLANE);
        }
        int b = Ctx.batteryPercent(this);
        if (b >= 0 && b <= 10 && !Ctx.charging(this)) {
            award(Puzzles.LOW_BATT);
        }
        if (b == 42) {
            award(Puzzles.BATT42);
        }
        if (Ctx.dayOfWeek() == Calendar.MONDAY) {
            award(Puzzles.MONDAY);
        }
        boolean keys = Ctx.imeSelected(this, PKG_KEYS);
        boolean web = Ctx.installed(this, PKG_WEB);
        if (mouseMode) {
            award(Puzzles.MOUSE);
        }
        if (keys) {
            award(Puzzles.KEYS);
        }
        if (web) {
            award(Puzzles.FLOATWEB);
        }
        if (mouseMode && keys && web) {
            award(Puzzles.TRILOGY);
        }
        if (Ctx.totalMem(this) < 2600000000L) {
            award(Puzzles.LOW_RAM);
        }
    }

    private void award(int id) {
        String m = puzzles.solve(id);
        if (m != null) {
            showBanner(m);
        }
    }

    // ------------------------------------------------------------------ banner and dialogs

    private void quip(int arrayRes) {
        String[] a = getResources().getStringArray(arrayRes);
        showBanner(a[rnd.nextInt(a.length)]);
    }

    private void showBanner(String msg) {
        queue.add(msg);
        if (!bannerBusy) {
            nextBanner();
        }
    }

    private void nextBanner() {
        if (queue.isEmpty()) {
            bannerBusy = false;
            banner.setVisibility(View.GONE);
            return;
        }
        bannerBusy = true;
        String m = queue.remove(0);
        banner.setText(m);
        banner.setVisibility(View.VISIBLE);
        ui.postDelayed(nextBannerRunnable, Math.min(8000, 2500 + m.length() * 50));
    }

    private void showHistory() {
        StringBuilder sb = new StringBuilder(getString(R.string.history_top)).append("\n\n");
        if (history.isEmpty()) {
            sb.append(getString(R.string.history_empty));
        } else {
            for (String h : history) {
                sb.append(h).append('\n');
            }
        }
        new AlertDialog.Builder(this).setTitle(R.string.history_title).setMessage(sb.toString())
                .setPositiveButton(R.string.ok, null).show();
    }

    private void showAbout() {
        String[] clues = getResources().getStringArray(R.array.about_clues);
        int n = store.bump("about");
        String clue = clues[Math.min(n - 1, clues.length - 1)];
        new AlertDialog.Builder(this).setTitle(R.string.about_title)
                .setMessage(getString(R.string.about_body) + "\n\n" + clue)
                .setPositiveButton(R.string.ok, null).show();
    }
}
