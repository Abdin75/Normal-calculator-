package com.smartcalc.app;

/** The calculator brain: what happens when a key is pressed. Pure Java (no Android). */
final class CalcState {

    private static final int MAX = 40;

    private final StringBuilder expr = new StringBuilder();
    private String result = "";
    private boolean fresh;

    boolean evaluated;     // true if the last key press evaluated something
    boolean emptyEquals;   // "=" pressed with nothing typed
    boolean error;         // the evaluation failed
    boolean divZero;       // ... because of a division by zero
    String lastExpr = "";  // the expression that was evaluated

    String expression() {
        return expr.toString();
    }

    String result() {
        return result;
    }

    boolean isFresh() {
        return fresh;
    }

    private static boolean isOp(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }

    private static boolean isDigit(char c) {
        return c >= '0' && c <= '9';
    }

    private char last() {
        return expr.length() == 0 ? '\0' : expr.charAt(expr.length() - 1);
    }

    private void startOver() {
        expr.setLength(0);
        result = "";
        fresh = false;
    }

    void press(String key) {
        evaluated = false;
        emptyEquals = false;
        error = false;
        divZero = false;
        if (key.length() == 1 && isDigit(key.charAt(0))) {
            digit(key.charAt(0));
            return;
        }
        switch (key) {
            case ".":
                dot();
                break;
            case "+":
            case "-":
            case "*":
            case "/":
                op(key.charAt(0));
                break;
            case "%":
                percent();
                break;
            case "()":
                paren();
                break;
            case "DEL":
                del();
                break;
            case "C":
                startOver();
                break;
            case "=":
                equalsKey();
                break;
            default:
                break;
        }
    }

    private void digit(char ch) {
        if (fresh) {
            startOver();
        }
        if (expr.length() < MAX) {
            expr.append(ch);
        }
    }

    private void dot() {
        if (fresh) {
            startOver();
        }
        if (expr.length() >= MAX) {
            return;
        }
        int i = expr.length() - 1;
        while (i >= 0 && (isDigit(expr.charAt(i)) || expr.charAt(i) == '.')) {
            if (expr.charAt(i) == '.') {
                return; // this number already has a dot
            }
            i--;
        }
        if (!isDigit(last())) {
            expr.append('0');
        }
        expr.append('.');
    }

    private void op(char c) {
        if (fresh) {
            boolean usable = result.length() > 0 && !result.equals("Error") && result.indexOf('e') < 0;
            expr.setLength(0);
            if (usable) {
                expr.append(result);
            }
            result = "";
            fresh = false;
        }
        if (expr.length() == 0) {
            if (c == '-') {
                expr.append('-');
            }
            return;
        }
        char l = last();
        if (isOp(l)) {
            if (expr.length() == 1) {
                if (c != '-') {
                    expr.setLength(0);
                }
                return;
            }
            expr.setCharAt(expr.length() - 1, c);
            return;
        }
        if (l == '(') {
            if (c == '-') {
                expr.append('-');
            }
            return;
        }
        if (expr.length() < MAX) {
            expr.append(c);
        }
    }

    private void percent() {
        char l = last();
        if (expr.length() < MAX && (isDigit(l) || l == ')' || l == '%')) {
            expr.append('%');
        }
    }

    private int openCount(CharSequence t) {
        int open = 0;
        for (int i = 0; i < t.length(); i++) {
            if (t.charAt(i) == '(') {
                open++;
            } else if (t.charAt(i) == ')') {
                open--;
            }
        }
        return open;
    }

    private void paren() {
        if (fresh) {
            startOver();
        }
        if (expr.length() >= MAX) {
            return;
        }
        char l = last();
        boolean valueBefore = isDigit(l) || l == ')' || l == '%';
        if (openCount(expr) > 0 && valueBefore) {
            expr.append(')');
        } else {
            if (valueBefore) {
                expr.append('*');
            }
            expr.append('(');
        }
    }

    private void del() {
        if (fresh) {
            startOver();
            return;
        }
        if (expr.length() > 0) {
            expr.setLength(expr.length() - 1);
        }
    }

    /** The expression with trailing operators removed and open brackets closed. */
    private String closed() {
        StringBuilder t = new StringBuilder(expr);
        while (t.length() > 0 && isOp(t.charAt(t.length() - 1))) {
            t.setLength(t.length() - 1);
        }
        int open = openCount(t);
        for (int i = 0; i < open; i++) {
            t.append(')');
        }
        return t.toString();
    }

    private void equalsKey() {
        if (expr.length() == 0) {
            emptyEquals = true;
            return;
        }
        String e = closed();
        if (e.length() == 0 || e.equals("-")) {
            return;
        }
        lastExpr = e;
        try {
            result = Calc.format(Calc.eval(e));
            error = result.equals("Error");
        } catch (ArithmeticException ex) {
            result = "Error";
            error = true;
            divZero = true;
        } catch (RuntimeException ex) {
            result = "Error";
            error = true;
        }
        evaluated = true;
        fresh = true;
    }

    /** Live result while typing (empty if there is nothing useful to show). */
    String preview() {
        if (fresh || expr.length() < 2) {
            return "";
        }
        boolean hasOperation = false;
        for (int i = 1; i < expr.length(); i++) {
            char ch = expr.charAt(i);
            if (isOp(ch) || ch == '%' || ch == '(') {
                hasOperation = true;
                break;
            }
        }
        if (!hasOperation) {
            return "";
        }
        try {
            String r = Calc.format(Calc.eval(closed()));
            return r.equals("Error") ? "" : r;
        } catch (RuntimeException ex) {
            return "";
        }
    }
}
