package com.smartcalc.app;

import android.content.Context;
import android.content.res.Resources;

/** The puzzle book: ids, texts (from resources) and the solved/unsolved state. */
final class Puzzles {

    static final int KNOCK = 0;
    static final int HOLD_EQ = 1;
    static final int HOLD_C = 2;
    static final int VERSION = 3;
    static final int CODE_42 = 4;
    static final int CODE_1337 = 5;
    static final int ZERO_DIV = 6;
    static final int FLOAT = 7;
    static final int CODE_7734 = 8;
    static final int CODE_PI = 9;
    static final int CODE_PHI = 10;
    static final int THIRD = 11;
    static final int EQ_SPAM = 12;
    static final int ZEROS = 13;
    static final int FAST_HANDS = 14;
    static final int NIGHT = 15;
    static final int AIRPLANE = 16;
    static final int LOW_BATT = 17;
    static final int BATT42 = 18;
    static final int MONDAY = 19;
    static final int MOUSE = 20;
    static final int KEYS = 21;
    static final int FLOATWEB = 22;
    static final int TRILOGY = 23;
    static final int STARS = 29;
    static final int KEYHUNT = 30;
    static final int SCRATCH = 31;
    static final int FINALE = 32;
    static final int RIGHT_MENU = 33;
    static final int LOW_RAM = 34;
    static final int TIME607 = 35;
    static final int BATT67 = 36;
    static final int TAP67 = 37;
    static final int SWIPE10 = 38;
    static final int LAUNCH10 = 39;
    static final int LAUNCH50 = 40;
    static final int LAUNCH100 = 41;
    static final int CALC50 = 42;
    static final int CALC200 = 43;
    static final int CALC1000 = 44;
    static final int STREAK3 = 45;
    static final int STREAK7 = 46;
    static final int PIDAY = 47;
    static final int APRIL1 = 48;
    static final int HALLOWEEN = 49;
    static final int NEWYEAR = 50;
    static final int FRI13 = 51;
    static final int MIDNIGHT = 52;
    static final int EARLYBIRD = 53;
    static final int SHOP_VISIT = 54;
    static final int HIDDEN_PAGE = 100;
    static final int PW_STRONG = 101;
    static final int PW_WEAK = 102;
    static final int COUNT = 103;

    private static final int[] RANK_AT = {0, 5, 15, 30, 50, 75, 95};

    private final Store store;
    private final String[] titles;
    private final String[] hints;
    private final String[] wins;
    private final String[] answers;
    private final String[] digits;
    private final String[] ranks;
    private final int[] art;
    private final int[] slot;
    private final int[] kind;
    private final String[] codeHash;
    private final int[] codeId;
    private final String[] exprKey;
    private final int[] exprId;
    private final String[] bakedDigits;
    private final String[] bakedMessages;
    private final int total;
    private final String codePart;
    private final String newPuzzle;

    private static String[] fit(String[] a, int n, String fill) {
        String[] out = new String[n];
        for (int i = 0; i < n; i++) {
            out[i] = i < a.length ? a[i] : fill;
        }
        return out;
    }

    private static int[] fitInts(int[] a, int n, int fill) {
        int[] out = new int[n];
        for (int i = 0; i < n; i++) {
            out[i] = i < a.length ? a[i] : fill;
        }
        return out;
    }

    private static String[] join(String[] a, String[] b, int nb) {
        String[] out = new String[a.length + nb];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, nb);
        return out;
    }

    private static String[] padS(String[] a, int extra, String value) {
        String[] out = new String[a.length + extra];
        System.arraycopy(a, 0, out, 0, a.length);
        for (int i = 0; i < extra; i++) {
            out[a.length + i] = value;
        }
        return out;
    }

    private static int[] padI(int[] a, int extra, int value) {
        int[] out = new int[a.length + extra];
        System.arraycopy(a, 0, out, 0, a.length);
        for (int i = 0; i < extra; i++) {
            out[a.length + i] = value;
        }
        return out;
    }

    Puzzles(Context c, Store s) {
        Resources r = c.getResources();
        store = s;
        String[] et = r.getStringArray(R.array.extra_titles);
        String[] eq = r.getStringArray(R.array.extra_questions);
        String[] ew = r.getStringArray(R.array.extra_wins);
        String[] ea = r.getStringArray(R.array.extra_answers);
        int extra = Math.min(Math.min(et.length, eq.length), Math.min(ew.length, ea.length));
        extra = Math.min(extra, 150);
        total = COUNT + extra;
        titles = join(fit(r.getStringArray(R.array.puzzle_titles), COUNT, "?"), et, extra);
        hints = join(fit(r.getStringArray(R.array.puzzle_hints), COUNT, "?"), eq, extra);
        wins = join(fit(r.getStringArray(R.array.puzzle_wins), COUNT, "?"), ew, extra);
        answers = join(fit(r.getStringArray(R.array.puzzle_answers), COUNT, "-"), ea, extra);
        digits = padS(fit(r.getStringArray(R.array.puzzle_frag_digit), COUNT, "-"), extra, "-");
        art = padI(fitInts(r.getIntArray(R.array.puzzle_art), COUNT, -1), extra, -1);
        slot = padI(fitInts(r.getIntArray(R.array.puzzle_frag_slot), COUNT, 0), extra, 0);
        kind = padI(fitInts(r.getIntArray(R.array.puzzle_kind), COUNT, 0), extra, 1);
        ranks = r.getStringArray(R.array.ranks);
        codePart = r.getString(R.string.code_part);
        newPuzzle = r.getString(R.string.new_puzzle);

        String[] ch = r.getStringArray(R.array.code_hashes);
        codeHash = new String[ch.length];
        codeId = new int[ch.length];
        for (int i = 0; i < ch.length; i++) {
            int bar = ch[i].indexOf('|');
            codeHash[i] = ch[i].substring(0, bar).trim();
            codeId[i] = Integer.parseInt(ch[i].substring(bar + 1).trim());
        }
        String[] em = r.getStringArray(R.array.expr_map);
        exprKey = new String[em.length];
        exprId = new int[em.length];
        for (int i = 0; i < em.length; i++) {
            int bar = em[i].lastIndexOf('|');
            exprKey[i] = em[i].substring(0, bar).trim();
            exprId[i] = Integer.parseInt(em[i].substring(bar + 1).trim());
        }
        bakedDigits = r.getStringArray(R.array.extra_code_digits);
        bakedMessages = r.getStringArray(R.array.extra_code_messages);
    }

    int total() {
        return total;
    }

    String title(int id) {
        return titles[id];
    }

    String hint(int id) {
        return hints[id];
    }

    String win(int id) {
        return wins[id];
    }

    int art(int id) {
        return art[id];
    }

    int slot(int id) {
        return slot[id];
    }

    boolean isTyped(int id) {
        return id >= 0 && id < total && kind[id] == 1;
    }

    boolean isExtra(int id) {
        return id >= COUNT && id < total;
    }

    /** The first accepted answer, shown after the puzzle is solved. */
    String answerShown(int id) {
        String a = answers[id];
        int bar = a.indexOf('|');
        return bar > 0 ? a.substring(0, bar) : a;
    }

    /** Checks a typed answer (marks, spaces and alef forms are ignored). */
    boolean check(int id, String typed) {
        if (!isTyped(id)) {
            return false;
        }
        String t = Norm.arabic(typed);
        if (t.length() == 0) {
            return false;
        }
        for (String a : answers[id].split("\\|")) {
            if (t.equals(Norm.arabic(a))) {
                return true;
            }
        }
        return false;
    }

    /** The code digit this puzzle reveals, or "" if it reveals none. */
    String digit(int id) {
        return digits[id].equals("-") ? "" : digits[id];
    }

    boolean solved(int id) {
        return store.has(id);
    }

    int solvedCount() {
        return store.count();
    }

    String rank() {
        int n = store.count();
        int idx = 0;
        for (int i = 0; i < RANK_AT.length; i++) {
            if (n >= RANK_AT[i]) {
                idx = i;
            }
        }
        return ranks[Math.min(idx, ranks.length - 1)];
    }

    /** Marks the puzzle solved and returns the text to show, or null if it was already solved. */
    String solve(int id) {
        if (id < 0 || id >= total || !store.set(id)) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("\uD83D\uDD13 ").append(newPuzzle).append(": ").append(titles[id]);
        sb.append("\n").append(wins[id]);
        String d = digit(id);
        if (d.length() > 0) {
            sb.append("\n\uD83D\uDD11 ").append(codePart).append(": ").append(d);
        }
        return sb.toString();
    }

    /** Which puzzle does this typed number belong to? -1 if none. */
    int matchCode(String typed) {
        String h = Norm.sha256Hex(typed);
        for (int i = 0; i < codeHash.length; i++) {
            if (codeHash[i].equals(h)) {
                return codeId[i];
            }
        }
        return -1;
    }

    /** Puzzles that react to a certain calculation (or to its result when the key starts with =). */
    int matchExpr(String expr, String result) {
        for (int i = 0; i < exprKey.length; i++) {
            String k = exprKey[i];
            if (k.startsWith("=") ? result.equals(k.substring(1)) : expr.equals(k)) {
                return exprId[i];
            }
        }
        return -1;
    }

    /** A message for a number puzzle that is baked into arrays.xml, or null. */
    String baked(String typed) {
        int n = Math.min(bakedDigits.length, bakedMessages.length);
        for (int i = 0; i < n; i++) {
            if (bakedDigits[i].trim().equals(typed)) {
                return bakedMessages[i];
            }
        }
        return null;
    }

    /** The five code digits in slot order, with '_' for the ones not found yet. */
    String codeSlots() {
        char[] out = {'_', '_', '_', '_', '_'};
        for (int id = 0; id < COUNT; id++) {
            int sl = slot[id];
            if (sl >= 1 && sl <= 5 && store.has(id) && digit(id).length() > 0) {
                out[sl - 1] = digit(id).charAt(0);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(out[i]);
            if (i < 4) {
                sb.append(' ');
            }
        }
        return sb.toString();
    }

    boolean codeComplete() {
        return codeSlots().indexOf('_') < 0;
    }
}
