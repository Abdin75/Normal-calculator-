package com.smartcalc.app;

import android.content.Context;
import android.content.res.Resources;

/** The puzzle book: ids, texts (from resources) and the solved/unsolved state. */
final class Puzzles {

    static final int KNOCK = 0;
    static final int HOLD_EQ = 1;
    static final int HOLD_C = 2;
    static final int VERSION = 3;
    static final int CODE_42 = 4;
    static final int CODE_1337 = 5;
    static final int ZERO_DIV = 6;
    static final int FLOAT = 7;
    static final int CODE_7734 = 8;
    static final int CODE_PI = 9;
    static final int CODE_PHI = 10;
    static final int THIRD = 11;
    static final int EQ_SPAM = 12;
    static final int ZEROS = 13;
    static final int FAST_HANDS = 14;
    static final int NIGHT = 15;
    static final int AIRPLANE = 16;
    static final int LOW_BATT = 17;
    static final int BATT42 = 18;
    static final int MONDAY = 19;
    static final int MOUSE = 20;
    static final int KEYS = 21;
    static final int FLOATWEB = 22;
    static final int TRILOGY = 23;
    static final int RIDDLE_FIRST = 24;
    static final int RIDDLE_COUNT = 5;
    static final int STARS = 29;
    static final int KEYHUNT = 30;
    static final int SCRATCH = 31;
    static final int FINALE = 32;
    static final int RIGHT_MENU = 33;
    static final int LOW_RAM = 34;
    static final int COUNT = 35;

    /** Typed codes: only their hashes live in the app. */
    private static final int[] CODE_IDS = {CODE_42, CODE_1337, CODE_7734, CODE_PI, CODE_PHI, FINALE};
    private static final String[] CODE_HASHES = {"73475cb40a568e8da8a045ced110137e159f890ac4da883b6b17dc651b3a8049", "5db1fee4b5703808c48078a76768b155b421b210c0761cd6a5d223f4d99f1eaa", "ab7a9032a205045ac82ea11013ba03e55acd10c9f2e8db7fb45d92d5caf3b057", "c5b389beb081fe1e43ae92e895deca086b4eed5cf9efc7b78eebbbc9dc75c3f0", "ae92bee5080ffa3533774ef98ec7858b08a02fed6778ab5d2043d0c64028e2d6", "870abe0e225024694b41f1fc2954ac92489374c3ab51890e5964ecdcf76f8c8c"};
    private static final int[] RANK_AT = {0, 3, 8, 15, 24, 32};

    private final Store store;
    private final String[] titles;
    private final String[] hints;
    private final String[] wins;
    private final String[] digits;
    private final String[] ranks;
    private final int[] art;
    private final int[] slot;
    private final String codePart;
    private final String newPuzzle;

    Puzzles(Context c, Store s) {
        Resources r = c.getResources();
        store = s;
        titles = r.getStringArray(R.array.puzzle_titles);
        hints = r.getStringArray(R.array.puzzle_hints);
        wins = r.getStringArray(R.array.puzzle_wins);
        digits = r.getStringArray(R.array.puzzle_frag_digit);
        ranks = r.getStringArray(R.array.ranks);
        art = r.getIntArray(R.array.puzzle_art);
        slot = r.getIntArray(R.array.puzzle_frag_slot);
        codePart = r.getString(R.string.code_part);
        newPuzzle = r.getString(R.string.new_puzzle);
    }

    String title(int id) {
        return titles[id];
    }

    String hint(int id) {
        return hints[id];
    }

    String win(int id) {
        return wins[id];
    }

    int art(int id) {
        return art[id];
    }

    int slot(int id) {
        return slot[id];
    }

    /** The code digit this puzzle reveals, or "" if it reveals none. */
    String digit(int id) {
        return digits[id].equals("-") ? "" : digits[id];
    }

    boolean solved(int id) {
        return store.has(id);
    }

    int solvedCount() {
        return store.count();
    }

    String rank() {
        int n = store.count();
        int idx = 0;
        for (int i = 0; i < RANK_AT.length; i++) {
            if (n >= RANK_AT[i]) {
                idx = i;
            }
        }
        return ranks[Math.min(idx, ranks.length - 1)];
    }

    /** Marks the puzzle solved and returns the text to show, or null if it was already solved. */
    String solve(int id) {
        if (id < 0 || id >= COUNT || !store.set(id)) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("\uD83D\uDD13 ").append(newPuzzle).append(": ").append(titles[id]);
        sb.append("\n").append(wins[id]);
        String d = digit(id);
        if (d.length() > 0) {
            sb.append("\n\uD83D\uDD11 ").append(codePart).append(": ").append(d);
        }
        return sb.toString();
    }

    /** Which puzzle does this typed number belong to? -1 if none. */
    int matchCode(String typed) {
        String h = Norm.sha256Hex(typed);
        for (int i = 0; i < CODE_IDS.length; i++) {
            if (CODE_HASHES[i].equals(h)) {
                return CODE_IDS[i];
            }
        }
        return -1;
    }

    /** The five code digits in slot order, with '_' for the ones not found yet. */
    String codeSlots() {
        char[] out = {'_', '_', '_', '_', '_'};
        for (int id = 0; id < COUNT; id++) {
            int sl = slot[id];
            if (sl >= 1 && sl <= 5 && store.has(id) && digit(id).length() > 0) {
                out[sl - 1] = digit(id).charAt(0);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            sb.append(out[i]);
            if (i < 4) {
                sb.append(' ');
            }
        }
        return sb.toString();
    }

    boolean codeComplete() {
        return codeSlots().indexOf('_') < 0;
    }
}
