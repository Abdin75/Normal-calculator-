package com.smartcalc.app;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;

/**
 * Optional custom media. You pick a folder with the system picker; files named p00 ... p34
 * (any image or video) replace the built-in picture of that puzzle once it is solved.
 * The folder belongs to you, so any file manager can change what is in it.
 */
final class MediaLib {

    private static final String KEY = "media_tree";

    private MediaLib() {
    }

    static Uri tree(Context c) {
        String s = c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).getString(KEY, null);
        return s == null ? null : Uri.parse(s);
    }

    static void saveTree(Context c, Uri uri) {
        try {
            c.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (RuntimeException ignored) {
            // some pickers do not offer a persistable grant
        }
        c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).edit().putString(KEY, uri.toString()).apply();
    }

    static void clearTree(Context c) {
        c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }

    /** A picture or video you chose for one puzzle (needs the Pictures feature). */
    static Uri puzzleUri(Context c, int puzzleId) {
        String s = c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).getString("pm_" + puzzleId, null);
        return s == null ? null : Uri.parse(s);
    }

    static void setPuzzleUri(Context c, int puzzleId, Uri uri) {
        try {
            c.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (RuntimeException ignored) {
            // some pickers do not offer a persistable grant
        }
        c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).edit().putString("pm_" + puzzleId, uri.toString()).apply();
    }

    static void clearPuzzleUri(Context c, int puzzleId) {
        c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).edit().remove("pm_" + puzzleId).apply();
    }

    static String key(int puzzleId) {
        return String.format(Locale.ROOT, "p%02d", puzzleId);
    }

    /** Maps "p04" (lower case, without extension) to the file in the chosen folder. */
    static HashMap<String, Uri> list(Context c) {
        HashMap<String, Uri> out = new HashMap<String, Uri>();
        Uri tree = tree(c);
        if (tree == null) {
            return out;
        }
        Cursor cur = null;
        try {
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree,
                    DocumentsContract.getTreeDocumentId(tree));
            cur = c.getContentResolver().query(children, new String[] {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            while (cur != null && cur.moveToNext()) {
                String id = cur.getString(0);
                String name = cur.getString(1);
                if (id == null || name == null) {
                    continue;
                }
                int dot = name.lastIndexOf('.');
                String base = (dot > 0 ? name.substring(0, dot) : name).toLowerCase(Locale.ROOT);
                if (!out.containsKey(base)) {
                    out.put(base, DocumentsContract.buildDocumentUriUsingTree(tree, id));
                }
            }
        } catch (Exception e) {
            // folder deleted or permission lost: behave as if it were empty
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        return out;
    }

    static boolean isVideo(Context c, Uri u) {
        String t = c.getContentResolver().getType(u);
        return t != null && t.startsWith("video/");
    }

    /** Decodes a small version of the image (keeps RAM low on a 2 GB phone). */
    static Bitmap loadImage(Context c, Uri u, int maxPx) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(u);
            BitmapFactory.decodeStream(in, null, o);
            if (in != null) {
                in.close();
            }
            int sample = 1;
            int big = Math.max(o.outWidth, o.outHeight);
            while (big / sample > maxPx) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            in = c.getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            if (in != null) {
                in.close();
            }
            return b;
        } catch (Exception e) {
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ copies kept inside the app

    private static File dir(Context c) {
        File d = new File(c.getFilesDir(), "media");
        if (!d.exists()) {
            d.mkdirs();
        }
        return d;
    }

    /** Saves a small copy of a picture inside the app, so it stays even if the original moves. */
    static boolean savePrivateImage(Context c, Uri src, String name) {
        Bitmap b = loadImage(c, src, 1080);
        if (b == null) {
            return false;
        }
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(new File(dir(c), name + ".jpg"));
            b.compress(Bitmap.CompressFormat.JPEG, 88, out);
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (Exception ignored) {
                // nothing to do
            }
        }
    }

    static boolean hasPrivateImage(Context c, String name) {
        return new File(dir(c), name + ".jpg").exists();
    }

    static void deletePrivateImage(Context c, String name) {
        new File(dir(c), name + ".jpg").delete();
    }

    static Bitmap loadPrivateImage(Context c, String name, int maxPx) {
        try {
            String path = new File(dir(c), name + ".jpg").getAbsolutePath();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            int sample = 1;
            int big = Math.max(o.outWidth, o.outHeight);
            while (big / sample > maxPx) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeFile(path, o2);
        } catch (Exception e) {
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }

    static boolean hasBaked(Context c, int puzzleId) {
        return c.getResources().getIdentifier("pz_" + puzzleId, "drawable", c.getPackageName()) != 0;
    }

    /** A picture baked into the app: a file named pz_<id> in res/drawable-nodpi (see the guide). */
    static Bitmap loadBaked(Context c, int puzzleId, int maxPx) {
        int res = c.getResources().getIdentifier("pz_" + puzzleId, "drawable", c.getPackageName());
        if (res == 0) {
            return null;
        }
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeResource(c.getResources(), res, o);
            int sample = 1;
            int big = Math.max(o.outWidth, o.outHeight);
            while (big / sample > maxPx) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            return BitmapFactory.decodeResource(c.getResources(), res, o2);
        } catch (Exception e) {
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }
}
