package com.smartcalc.app;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.DocumentsContract;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;

/**
 * Optional custom media. You pick a folder with the system picker; files named p00 ... p34
 * (any image or video) replace the built-in picture of that puzzle once it is solved.
 * The folder belongs to you, so any file manager can change what is in it.
 */
final class MediaLib {

    private static final String KEY = "media_tree";

    private MediaLib() {
    }

    static Uri tree(Context c) {
        String s = c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).getString(KEY, null);
        return s == null ? null : Uri.parse(s);
    }

    static void saveTree(Context c, Uri uri) {
        try {
            c.getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (RuntimeException ignored) {
            // some pickers do not offer a persistable grant
        }
        c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).edit().putString(KEY, uri.toString()).apply();
    }

    static void clearTree(Context c) {
        c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }

    static String key(int puzzleId) {
        return String.format(Locale.ROOT, "p%02d", puzzleId);
    }

    /** Maps "p04" (lower case, without extension) to the file in the chosen folder. */
    static HashMap<String, Uri> list(Context c) {
        HashMap<String, Uri> out = new HashMap<String, Uri>();
        Uri tree = tree(c);
        if (tree == null) {
            return out;
        }
        Cursor cur = null;
        try {
            Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree,
                    DocumentsContract.getTreeDocumentId(tree));
            cur = c.getContentResolver().query(children, new String[] {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            while (cur != null && cur.moveToNext()) {
                String id = cur.getString(0);
                String name = cur.getString(1);
                if (id == null || name == null) {
                    continue;
                }
                int dot = name.lastIndexOf('.');
                String base = (dot > 0 ? name.substring(0, dot) : name).toLowerCase(Locale.ROOT);
                if (!out.containsKey(base)) {
                    out.put(base, DocumentsContract.buildDocumentUriUsingTree(tree, id));
                }
            }
        } catch (Exception e) {
            // folder deleted or permission lost: behave as if it were empty
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        return out;
    }

    static boolean isVideo(Context c, Uri u) {
        String t = c.getContentResolver().getType(u);
        return t != null && t.startsWith("video/");
    }

    /** Decodes a small version of the image (keeps RAM low on a 2 GB phone). */
    static Bitmap loadImage(Context c, Uri u, int maxPx) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            InputStream in = c.getContentResolver().openInputStream(u);
            BitmapFactory.decodeStream(in, null, o);
            if (in != null) {
                in.close();
            }
            int sample = 1;
            int big = Math.max(o.outWidth, o.outHeight);
            while (big / sample > maxPx) {
                sample *= 2;
            }
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            o2.inPreferredConfig = Bitmap.Config.RGB_565;
            in = c.getContentResolver().openInputStream(u);
            Bitmap b = BitmapFactory.decodeStream(in, null, o2);
            if (in != null) {
                in.close();
            }
            return b;
        } catch (Exception e) {
            return null;
        } catch (OutOfMemoryError e) {
            return null;
        }
    }
}
