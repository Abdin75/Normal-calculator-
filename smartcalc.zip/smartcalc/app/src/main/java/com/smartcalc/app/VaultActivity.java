package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

/** The layer under the calculator: progress, pictures, riddles, lab and your own media. */
public class VaultActivity extends Activity {

    private static final int REQ_TREE = 7;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Random rnd = new Random();
    private Store store;
    private Puzzles puzzles;
    private float dp;
    private boolean ready;
    private HashMap<String, Uri> media = new HashMap<String, Uri>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        if (!store.has(Puzzles.KNOCK)) {
            finish();
            return;
        }
        ready = true;
        String msg = getIntent().getStringExtra("msg");
        if (msg != null) {
            showMessage(msg);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!ready) {
            return;
        }
        store.refresh();
        media = MediaLib.list(this);
        build();
    }

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private TextView header(String text) {
        TextView t = tv(text, 18, 0xFFFFB300);
        t.setPadding(0, (int) (22 * dp), 0, (int) (6 * dp));
        return t;
    }

    private void showMessage(String msg) {
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton(R.string.ok, null).show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private String idLabel(int id) {
        return String.format(Locale.ROOT, "p%02d", id);
    }

    // ------------------------------------------------------------------ screen

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF101418);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * dp);
        box.setPadding(pad, pad, pad, pad * 2);
        sv.addView(box);

        box.addView(tv(getString(R.string.vault_title), 26, 0xFFFFB300));
        box.addView(tv(getString(R.string.vault_rank) + ": " + puzzles.rank()
                + "   (" + puzzles.solvedCount() + " / " + Puzzles.COUNT + ")", 16, 0xFFECEFF1));
        TextView code = tv(getString(R.string.vault_code) + ":   " + puzzles.codeSlots(), 22, 0xFF80CBC4);
        code.setPadding(0, (int) (10 * dp), 0, 0);
        box.addView(code);
        box.addView(tv(getString(puzzles.codeComplete() ? R.string.vault_code_done
                : R.string.vault_code_more), 14, 0xFF90A4AE));

        buildGallery(box);
        buildLab(box);
        buildRiddles(box);
        buildPuzzleList(box);
        buildMedia(box);

        String[] foot = getResources().getStringArray(R.array.vault_footers);
        TextView f = tv(foot[rnd.nextInt(foot.length)], 13, 0xFF607D8B);
        f.setPadding(0, (int) (26 * dp), 0, 0);
        box.addView(f);

        setContentView(sv);
    }

    private boolean isRiddle(int id) {
        return id >= Puzzles.RIDDLE_FIRST && id < Puzzles.RIDDLE_FIRST + Puzzles.RIDDLE_COUNT;
    }

    private void buildGallery(LinearLayout box) {
        box.addView(header(getString(R.string.vault_gallery)));
        LinearLayout row = null;
        int inRow = 0;
        for (int id = 0; id < Puzzles.COUNT; id++) {
            boolean custom = media.containsKey(MediaLib.key(id));
            if (puzzles.art(id) < 0 && !custom) {
                continue;
            }
            if (row == null || inRow == 3) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                box.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
                inRow = 0;
            }
            row.addView(galleryCell(id, custom), new LinearLayout.LayoutParams(0, WRAP, 1f));
            inRow++;
        }
        while (row != null && inRow > 0 && inRow < 3) {
            row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            inRow++;
        }
    }

    private View galleryCell(final int id, boolean custom) {
        final boolean solved = puzzles.solved(id);
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        int m = (int) (4 * dp);
        cell.setPadding(m, m, m, m);
        ArtView art = new ArtView(this, Math.max(0, puzzles.art(id)), !solved);
        if (solved && custom) {
            Uri u = media.get(MediaLib.key(id));
            boolean video = MediaLib.isVideo(this, u);
            art.setCustom(video ? null : MediaLib.loadImage(this, u, 320), video);
        }
        cell.addView(art, new LinearLayout.LayoutParams(MATCH, (int) (100 * dp)));
        String caption = solved ? idLabel(id) + "  " + puzzles.title(id) : idLabel(id) + "  ?";
        TextView cap = tv(caption, 11, solved ? 0xFFB0BEC5 : 0xFF607D8B);
        cap.setSingleLine(true);
        cell.addView(cap);
        final boolean hasCustom = custom;
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!solved) {
                    showMessage(puzzles.hint(id));
                } else if (hasCustom) {
                    showMedia(id);
                } else {
                    showBigArt(id);
                }
            }
        });
        return cell;
    }

    private void showBigArt(int id) {
        ArtView big = new ArtView(this, puzzles.art(id), false);
        big.setLayoutParams(new ViewGroup.LayoutParams(MATCH, (int) (300 * dp)));
        new AlertDialog.Builder(this).setTitle(puzzles.title(id)).setMessage(puzzles.win(id))
                .setView(big).setPositiveButton(R.string.close, null).show();
    }

    private void buildLab(LinearLayout box) {
        box.addView(header(getString(R.string.vault_lab)));
        int[] names = {R.string.lab_stars, R.string.lab_key, R.string.lab_scratch};
        for (int i = 0; i < names.length; i++) {
            final int mode = i;
            Button b = new Button(this);
            b.setText(names[i]);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(VaultActivity.this, PlayActivity.class).putExtra("mode", mode));
                }
            });
            box.addView(b);
        }
    }

    private void buildRiddles(LinearLayout box) {
        box.addView(header(getString(R.string.vault_riddles)));
        final String[] hashes = getResources().getStringArray(R.array.riddle_hashes);
        String[] answers = getResources().getStringArray(R.array.riddle_answers);
        for (int i = 0; i < Puzzles.RIDDLE_COUNT; i++) {
            final int id = Puzzles.RIDDLE_FIRST + i;
            final int idx = i;
            TextView q = tv(puzzles.title(id) + ": " + puzzles.hint(id), 15, 0xFFECEFF1);
            q.setPadding(0, (int) (8 * dp), 0, (int) (2 * dp));
            box.addView(q);
            if (puzzles.solved(id)) {
                box.addView(tv("\u2714 " + getString(R.string.riddle_answer) + ": " + answers[i], 14, 0xFF81C784));
                continue;
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            final EditText et = new EditText(this);
            et.setHint(R.string.riddle_hint);
            et.setSingleLine(true);
            et.setTextColor(0xFFFFFFFF);
            et.setHintTextColor(0xFF607D8B);
            row.addView(et, new LinearLayout.LayoutParams(0, WRAP, 1f));
            Button go = new Button(this);
            go.setText(R.string.riddle_try);
            go.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String typed = et.getText().toString();
                    if (typed.trim().length() > 0 && Norm.matches(typed, hashes[idx])) {
                        String m = puzzles.solve(id);
                        if (m != null) {
                            showMessage(m);
                        }
                        build();
                    } else {
                        String[] w = getResources().getStringArray(R.array.quips_wrong);
                        toast(w[rnd.nextInt(w.length)]);
                    }
                }
            });
            row.addView(go, new LinearLayout.LayoutParams(WRAP, WRAP));
            box.addView(row);
        }
    }

    private void buildPuzzleList(LinearLayout box) {
        box.addView(header(getString(R.string.vault_puzzles)));
        for (int id = 0; id < Puzzles.COUNT; id++) {
            if (isRiddle(id)) {
                continue;
            }
            boolean solved = puzzles.solved(id);
            String text = solved
                    ? "\u2714 " + idLabel(id) + "  " + puzzles.title(id) + "\n" + puzzles.win(id)
                    : "\uD83D\uDD12 " + idLabel(id) + "  " + puzzles.hint(id);
            TextView t = tv(text, 14, solved ? 0xFFB0BEC5 : 0xFF78909C);
            t.setPadding(0, (int) (6 * dp), 0, (int) (6 * dp));
            box.addView(t);
        }
    }

    // ------------------------------------------------------------------ your own media

    private void buildMedia(LinearLayout box) {
        box.addView(header(getString(R.string.vault_media)));
        boolean chosen = MediaLib.tree(this) != null;
        box.addView(tv(getString(chosen ? R.string.media_current : R.string.media_none), 14, 0xFFB0BEC5));
        box.addView(tv(getString(R.string.media_help), 13, 0xFF78909C));
        Button pick = new Button(this);
        pick.setText(R.string.media_choose);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_TREE);
            }
        });
        box.addView(pick);
        if (chosen) {
            Button remove = new Button(this);
            remove.setText(R.string.media_remove);
            remove.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MediaLib.clearTree(VaultActivity.this);
                    media = MediaLib.list(VaultActivity.this);
                    build();
                }
            });
            box.addView(remove);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_TREE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            MediaLib.saveTree(this, data.getData());
            media = MediaLib.list(this);
            build();
        }
    }

    private void showMedia(int id) {
        Uri u = media.get(MediaLib.key(id));
        if (u == null) {
            toast(getString(R.string.media_missing));
            return;
        }
        if (MediaLib.isVideo(this, u)) {
            final VideoView vv = new VideoView(this);
            vv.setLayoutParams(new ViewGroup.LayoutParams(MATCH, (int) (260 * dp)));
            vv.setVideoURI(u);
            vv.setMediaController(new MediaController(this));
            AlertDialog d = new AlertDialog.Builder(this).setView(vv)
                    .setPositiveButton(R.string.close, null).create();
            d.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    vv.stopPlayback();
                }
            });
            d.show();
            vv.start();
        } else {
            Bitmap b = MediaLib.loadImage(this, u, 1080);
            if (b == null) {
                toast(getString(R.string.media_missing));
                return;
            }
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(b);
            iv.setAdjustViewBounds(true);
            new AlertDialog.Builder(this).setView(iv).setPositiveButton(R.string.close, null).show();
        }
    }
}
