package com.smartcalc.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.HashMap;
import java.util.Locale;
import java.util.Random;

/** The layer under the calculator: progress, gallery, lab, riddles, gifts, shop and your pictures. */
public class VaultActivity extends Activity {

    private static final int REQ_TREE = 7;
    private static final int REQ_PICK = 8;
    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private final Random rnd = new Random();
    private Store store;
    private Puzzles puzzles;
    private Entitlements ent;
    private Sfx sfx;
    private float dp;
    private boolean ready;
    private boolean canMedia;
    private int pendingId = -1;
    private HashMap<String, Uri> media = new HashMap<String, Uri>();

    /** What to show for a puzzle picture, in order of priority. */
    private static final class Src {
        Bitmap bmp;
        Uri uri;
        boolean video;
        boolean any;
    }

    /** A rounded progress bar. */
    private static final class BarView extends View {
        private final float fraction;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        BarView(Context c, float fraction) {
            super(c);
            this.fraction = Math.max(0f, Math.min(1f, fraction));
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth();
            float h = getHeight();
            p.setColor(0xFF2C3556);
            c.drawRoundRect(0, 0, w, h, h / 2f, h / 2f, p);
            p.setColor(0xFFFFC107);
            c.drawRoundRect(0, 0, Math.max(h, w * fraction), h, h / 2f, h / 2f, p);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dp = getResources().getDisplayMetrics().density;
        store = new Store(this);
        puzzles = new Puzzles(this, store);
        ent = new Entitlements(this, store);
        sfx = new Sfx(this);
        if (!store.has(Puzzles.KNOCK)) {
            finish();
            return;
        }
        ready = true;
        String msg = getIntent().getStringExtra("msg");
        if (msg != null) {
            showMessage(msg);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!ready) {
            return;
        }
        store.refresh();
        canMedia = ent.has(Entitlements.IMAGES);
        media = canMedia ? MediaLib.list(this) : new HashMap<String, Uri>();
        build();
    }

    // ------------------------------------------------------------------ small helpers

    private TextView tv(String text, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        return t;
    }

    private TextView header(String text) {
        TextView t = tv(text, 18, Ui.ACCENT);
        t.setPadding(0, 0, 0, (int) (8 * dp));
        return t;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.card(dp));
        int p = (int) (14 * dp);
        c.setPadding(p, p, p, p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        lp.setMargins(0, 0, 0, (int) (12 * dp));
        parent.addView(c, lp);
        return c;
    }

    private TextView pill(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTextColor(Ui.ACCENT);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.gradient(0xFF3A2E6E, 0xFF2D2358, 14 * dp));
        int p = (int) (12 * dp);
        t.setPadding(p, p, p, p);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        int m = (int) (3 * dp);
        lp.setMargins(m, m, m, m);
        return lp;
    }

    private LinearLayout.LayoutParams full() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
        int m = (int) (3 * dp);
        lp.setMargins(0, m, 0, m);
        return lp;
    }

    private void showMessage(String msg) {
        new AlertDialog.Builder(this).setMessage(msg).setPositiveButton(R.string.ok, null).show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    private String idLabel(int id) {
        return String.format(Locale.ROOT, "p%02d", id);
    }

    private String pmName(int id) {
        return "pm" + id;
    }

    private EditText input() {
        EditText et = new EditText(this);
        et.setHint(R.string.riddle_hint);
        et.setSingleLine(true);
        et.setTextColor(0xFFFFFFFF);
        et.setHintTextColor(0xFF607D8B);
        return et;
    }

    // ------------------------------------------------------------------ screen

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackground(Ui.page());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (14 * dp);
        box.setPadding(pad, pad, pad, pad * 2);
        sv.addView(box);

        LinearLayout head = card(box);
        head.addView(tv(getString(R.string.vault_title), 26, Ui.ACCENT));
        head.addView(tv(getString(R.string.vault_rank) + ": " + puzzles.rank()
                + "   (" + puzzles.solvedCount() + " / " + puzzles.total() + ")", 15, Ui.TEXT));
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(MATCH, (int) (10 * dp));
        bl.setMargins(0, (int) (10 * dp), 0, (int) (6 * dp));
        head.addView(new BarView(this, puzzles.solvedCount() / (float) puzzles.total()), bl);
        head.addView(tv(getString(R.string.vault_code) + ":   " + puzzles.codeSlots(), 22, 0xFF80CBC4));
        head.addView(tv(getString(puzzles.codeComplete() ? R.string.vault_code_done
                : R.string.vault_code_more), 13, Ui.MUTED));

        LinearLayout acts = card(box);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(pill("\uD83C\uDF81 " + getString(R.string.vault_gifts), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VaultActivity.this, GiftsActivity.class));
            }
        }), weighted());
        row.addView(pill("\uD83D\uDED2 " + getString(R.string.vault_shop), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VaultActivity.this, ShopActivity.class));
            }
        }), weighted());
        row.addView(pill("\uD83E\uDDE9 " + getString(R.string.vault_creator), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(VaultActivity.this, CreatorActivity.class));
            }
        }), weighted());
        acts.addView(row);

        buildGallery(box);
        buildLab(box);
        buildTyped(box);
        buildList(box);
        buildMedia(box);

        LinearLayout snd = card(box);
        snd.addView(pill(getString(sfx.enabled() ? R.string.sound_on : R.string.sound_off), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sfx.setEnabled(!sfx.enabled());
                if (sfx.enabled()) {
                    sfx.play(Sfx.POP);
                }
                build();
            }
        }), full());

        String[] foot = getResources().getStringArray(R.array.vault_footers);
        TextView f = tv(foot[rnd.nextInt(foot.length)], 13, 0xFF607D8B);
        f.setPadding(0, (int) (10 * dp), 0, 0);
        box.addView(f);
        setContentView(sv);
    }

    // ------------------------------------------------------------------ gallery

    private boolean hasCustomSource(int id) {
        return (canMedia && (MediaLib.hasPrivateImage(this, pmName(id))
                || MediaLib.puzzleUri(this, id) != null || media.containsKey(MediaLib.key(id))))
                || MediaLib.hasBaked(this, id);
    }

    private Src sourceFor(int id, int maxPx) {
        Src s = new Src();
        if (canMedia) {
            if (MediaLib.hasPrivateImage(this, pmName(id))) {
                s.bmp = MediaLib.loadPrivateImage(this, pmName(id), maxPx);
                s.any = s.bmp != null;
                if (s.any) {
                    return s;
                }
            }
            Uri u = MediaLib.puzzleUri(this, id);
            if (u == null) {
                u = media.get(MediaLib.key(id));
            }
            if (u != null) {
                s.uri = u;
                s.video = MediaLib.isVideo(this, u);
                if (!s.video) {
                    s.bmp = MediaLib.loadImage(this, u, maxPx);
                }
                s.any = s.video || s.bmp != null;
                if (s.any) {
                    return s;
                }
            }
        }
        if (MediaLib.hasBaked(this, id)) {
            s.bmp = MediaLib.loadBaked(this, id, maxPx);
            s.any = s.bmp != null;
        }
        return s;
    }

    private void buildGallery(LinearLayout box) {
        LinearLayout c = card(box);
        c.addView(header(getString(R.string.vault_gallery)));
        LinearLayout row = null;
        int inRow = 0;
        for (int id = 0; id < puzzles.total(); id++) {
            if (puzzles.art(id) < 0 && !hasCustomSource(id)) {
                continue;
            }
            if (row == null || inRow == 3) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                c.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
                inRow = 0;
            }
            row.addView(galleryCell(id), new LinearLayout.LayoutParams(0, WRAP, 1f));
            inRow++;
        }
        while (row != null && inRow > 0 && inRow < 3) {
            row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            inRow++;
        }
    }

    private View galleryCell(final int id) {
        final boolean solved = puzzles.solved(id);
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        int m = (int) (4 * dp);
        cell.setPadding(m, m, m, m);
        ArtView art = new ArtView(this, Math.max(0, puzzles.art(id)), !solved);
        boolean custom = false;
        if (solved) {
            Src s = sourceFor(id, 320);
            if (s.any) {
                art.setCustom(s.bmp, s.video);
                custom = true;
            }
        }
        cell.addView(art, new LinearLayout.LayoutParams(MATCH, (int) (100 * dp)));
        String caption = solved ? idLabel(id) + "  " + puzzles.title(id) : idLabel(id) + "  ?";
        TextView cap = tv(caption, 11, solved ? 0xFFB0BEC5 : 0xFF607D8B);
        cap.setSingleLine(true);
        cell.addView(cap);
        final boolean hasCustom = custom;
        cell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!solved) {
                    showMessage(puzzles.hint(id));
                } else if (hasCustom) {
                    showMedia(id);
                } else {
                    showBigArt(id);
                }
            }
        });
        cell.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (!solved) {
                    return false;
                }
                mediaOptions(id);
                return true;
            }
        });
        return cell;
    }

    private void showBigArt(int id) {
        ArtView big = new ArtView(this, Math.max(0, puzzles.art(id)), false);
        big.setLayoutParams(new ViewGroup.LayoutParams(MATCH, (int) (300 * dp)));
        new AlertDialog.Builder(this).setTitle(puzzles.title(id)).setMessage(puzzles.win(id))
                .setView(big).setPositiveButton(R.string.close, null).show();
    }

    private void showMedia(int id) {
        Src s = sourceFor(id, 1080);
        if (!s.any) {
            toast(getString(R.string.media_missing));
            return;
        }
        if (s.video) {
            final VideoView vv = new VideoView(this);
            vv.setLayoutParams(new ViewGroup.LayoutParams(MATCH, (int) (260 * dp)));
            vv.setVideoURI(s.uri);
            vv.setMediaController(new MediaController(this));
            AlertDialog d = new AlertDialog.Builder(this).setView(vv)
                    .setPositiveButton(R.string.close, null).create();
            d.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog) {
                    vv.stopPlayback();
                }
            });
            d.show();
            vv.start();
        } else {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(s.bmp);
            iv.setAdjustViewBounds(true);
            new AlertDialog.Builder(this).setView(iv).setPositiveButton(R.string.close, null).show();
        }
    }

    /** Long press on a solved picture: put your own picture or video there (paid feature). */
    private void mediaOptions(final int id) {
        if (!canMedia) {
            showMessage(getString(R.string.vault_media_paid));
            return;
        }
        String[] items = {getString(R.string.media_replace), getString(R.string.media_reset)};
        new AlertDialog.Builder(this).setTitle(puzzles.title(id))
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            pendingId = id;
                            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                            i.addCategory(Intent.CATEGORY_OPENABLE);
                            i.setType("*/*");
                            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {"image/*", "video/*"});
                            startActivityForResult(i, REQ_PICK);
                        } else {
                            MediaLib.deletePrivateImage(VaultActivity.this, pmName(id));
                            MediaLib.clearPuzzleUri(VaultActivity.this, id);
                            build();
                        }
                    }
                }).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        Uri uri = data.getData();
        if (requestCode == REQ_TREE) {
            MediaLib.saveTree(this, uri);
            media = MediaLib.list(this);
            build();
        } else if (requestCode == REQ_PICK && pendingId >= 0) {
            String type = getContentResolver().getType(uri);
            if (type != null && type.startsWith("video/")) {
                MediaLib.setPuzzleUri(this, pendingId, uri);
                MediaLib.deletePrivateImage(this, pmName(pendingId));
            } else if (MediaLib.savePrivateImage(this, uri, pmName(pendingId))) {
                MediaLib.clearPuzzleUri(this, pendingId);
                toast(getString(R.string.creator_image_saved));
            }
            pendingId = -1;
            build();
        }
    }

    // ------------------------------------------------------------------ lab, riddles, list

    private void buildLab(LinearLayout box) {
        LinearLayout c = card(box);
        c.addView(header(getString(R.string.vault_lab)));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int[] names = {R.string.lab_stars, R.string.lab_key, R.string.lab_scratch};
        for (int i = 0; i < names.length; i++) {
            final int mode = i;
            row.addView(pill(getString(names[i]), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(VaultActivity.this, PlayActivity.class).putExtra("mode", mode));
                }
            }), weighted());
        }
        c.addView(row);
    }

    private void buildTyped(LinearLayout box) {
        LinearLayout c = card(box);
        c.addView(header(getString(R.string.vault_riddles)));
        for (int i = 0; i < puzzles.total(); i++) {
            if (!puzzles.isTyped(i)) {
                continue;
            }
            final int id = i;
            TextView q = tv(idLabel(id) + "  " + puzzles.title(id) + ": " + puzzles.hint(id), 15, Ui.TEXT);
            q.setPadding(0, (int) (10 * dp), 0, (int) (2 * dp));
            c.addView(q);
            if (puzzles.solved(id)) {
                c.addView(tv("\u2714 " + getString(R.string.riddle_answer) + ": " + puzzles.answerShown(id), 14, 0xFF81C784));
                continue;
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            final EditText et = input();
            row.addView(et, new LinearLayout.LayoutParams(0, WRAP, 1f));
            row.addView(pill(getString(R.string.riddle_try), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (puzzles.check(id, et.getText().toString())) {
                        String m = puzzles.solve(id);
                        sfx.play(Sfx.SOLVE);
                        if (m != null) {
                            showMessage(m);
                        }
                        build();
                    } else {
                        String[] w = getResources().getStringArray(R.array.quips_wrong);
                        toast(w[rnd.nextInt(w.length)]);
                        sfx.play(Sfx.WRONG);
                    }
                }
            }), new LinearLayout.LayoutParams(WRAP, WRAP));
            c.addView(row);
        }
    }

    private void buildList(LinearLayout box) {
        LinearLayout c = card(box);
        c.addView(header(getString(R.string.vault_puzzles)));
        for (int id = 0; id < Puzzles.COUNT; id++) {
            if (puzzles.isTyped(id)) {
                continue;
            }
            boolean solved = puzzles.solved(id);
            String text = solved
                    ? "\u2714 " + idLabel(id) + "  " + puzzles.title(id) + "\n" + puzzles.win(id)
                    : "\uD83D\uDD12 " + idLabel(id) + "  " + puzzles.hint(id);
            TextView t = tv(text, 14, solved ? 0xFFB0BEC5 : 0xFF78909C);
            t.setPadding(0, (int) (6 * dp), 0, (int) (6 * dp));
            c.addView(t);
        }
    }

    // ------------------------------------------------------------------ pictures (paid feature)

    private void buildMedia(LinearLayout box) {
        LinearLayout c = card(box);
        c.addView(header(getString(R.string.vault_media)));
        if (!canMedia) {
            c.addView(tv(getString(R.string.vault_media_paid), 14, Ui.MUTED));
            c.addView(pill("\uD83D\uDED2 " + getString(R.string.vault_shop), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    startActivity(new Intent(VaultActivity.this, ShopActivity.class));
                }
            }), full());
            return;
        }
        boolean chosen = MediaLib.tree(this) != null;
        c.addView(tv(getString(chosen ? R.string.media_current : R.string.media_none), 14, 0xFFB0BEC5));
        c.addView(tv(getString(R.string.media_help), 13, Ui.MUTED));
        c.addView(pill(getString(R.string.media_choose), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(i, REQ_TREE);
            }
        }), full());
        if (chosen) {
            c.addView(pill(getString(R.string.media_remove), new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MediaLib.clearTree(VaultActivity.this);
                    media = MediaLib.list(VaultActivity.this);
                    build();
                }
            }), full());
        }
    }
}
